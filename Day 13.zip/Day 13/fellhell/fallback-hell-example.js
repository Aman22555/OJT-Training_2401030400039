function configureServer(options) {
    const configBad = {
        port: options.port || 8080,         
        timeout: options.timeout || 3000,   
        enableCache: options.enableCache || true,
        retries: options.retries || 5      
    };
    const configGood = {
        port: options.port ?? 8080,
        timeout: options.timeout ?? 3000,
        enableCache: options.enableCache ?? true,
        retries: options.retries ?? 5
    };

    return { configBad, configGood };
}
const userOptions = {
    port: 0,           
    timeout: 0,         
    enableCache: false, 
    retries: 0          
};

const result = configureServer(userOptions);

console.log("--- User Intended Options ---");
console.log(userOptions);
console.log("\n--- ❌ Bad Config (Fallback Hell) ---");
console.log(result.configBad);
console.log("\n--- ✅ Good Config (Nullish Coalescing) ---");
console.log(result.configGood);
