const express = require("express");
const multer = require("multer");
const path = require("path");

const app = express();
const PORT = 3000;

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});

const upload = multer({ storage });

app.get("/", (req, res) => {
  res.send(`
    <h2>File Upload</h2>
    <form action="/upload" method="POST" enctype="multipart/form-data">
      <input type="file" name="myFile" />
      <button type="submit">Upload</button>
    </form>
  `);
});

app.post("/upload", upload.single("myFile"), (req, res) => {
  if (!req.file) return res.send("No file uploaded.");
  res.send(`File uploaded successfully: ${req.file.filename}`);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
