# 🎮 GameStore — Enhanced Edition

Full-stack React + Node.js game store with:
- **Razorpay** live payment gateway (Cards, UPI, Net Banking, Wallets, EMI)
- **Google OAuth** via Firebase Authentication
- **Google Cloud Firestore** as database (user profiles, orders)
- **Admin User Management** — full user details, order history, profile viewer

---

## 🚀 Quick Start

### 1. Clone / extract project

```bash
cd gamestore-enhanced
```

### 2. Server setup

```bash
cd server
npm install
```

### 3. Client setup

```bash
cd client
npm install      # installs firebase automatically
```

---

## 🔑 Environment Variables

Create `server/.env`:

```env
# ── Razorpay ─────────────────────────────────
RAZORPAY_KEY_ID=rzp_test_XXXXXXXXXXXXXXXX
RAZORPAY_KEY_SECRET=your_razorpay_secret_here

# ── Google Cloud Firestore ───────────────────
GOOGLE_CLOUD_PROJECT=your-firebase-project-id
# OPTIONAL: path to service account JSON
GOOGLE_APPLICATION_CREDENTIALS=/path/to/serviceAccount.json

PORT=5000
```

Create `client/.env`:

```env
REACT_APP_FIREBASE_API_KEY=AIzaSy...
REACT_APP_FIREBASE_AUTH_DOMAIN=your-app.firebaseapp.com
REACT_APP_FIREBASE_PROJECT_ID=your-project-id
REACT_APP_FIREBASE_STORAGE_BUCKET=your-app.appspot.com
REACT_APP_FIREBASE_MESSAGING_SENDER_ID=000000000000
REACT_APP_FIREBASE_APP_ID=1:000:web:000
```

### Run both:

```bash
# Terminal 1 – server
cd server && node index.js

# Terminal 2 – client
cd client && npm start
```

---

## 🏦 Razorpay Setup (5 minutes)

1. Create a free account at https://razorpay.com
2. Go to **Settings → API Keys → Generate Test Key**
3. Copy `Key ID` → `RAZORPAY_KEY_ID`
4. Copy `Key Secret` → `RAZORPAY_KEY_SECRET`
5. For live payments, switch to Live mode keys

**Test card:** `4111 1111 1111 1111` · Expiry: any future · CVV: any 3 digits  
**Test UPI:** `success@razorpay`

> Without keys set, the app runs in **dev mode** — payments are simulated.

---

## 🔐 Google Cloud / Firebase Setup (10 minutes)

### Firebase Auth (for Google Login)

1. Go to https://console.firebase.google.com → Create project
2. **Authentication → Sign-in method → Google → Enable**
3. **Project Settings → Your apps → Add Web App**
4. Copy the `firebaseConfig` object → paste into `client/.env`
5. Add your domain to **Authorized domains** (localhost is auto-added)

### Firestore Database

1. In Firebase console → **Firestore Database → Create database**
2. Start in **test mode** (allows all reads/writes for 30 days)
3. **Project Settings → Service Accounts → Generate new private key**
4. Save the JSON file; set `GOOGLE_APPLICATION_CREDENTIALS` to its path

**Firestore Collections created automatically:**
- `users` — user profiles (email/Google), login history
- `orders` — every completed payment

> Without Firestore configured, the server falls back to **in-memory storage** — data resets on server restart.

---

## 👑 Admin Panel

URL: `/admin-login`  
Default credentials: `Aman Vishwakarma` / `G057528Aman@`  
Alternative: `admin` / `Admin@2025`

### Admin Sections:

| Section | Description |
|---------|-------------|
| **Dashboard** | Stats overview — games, users, revenue, orders today |
| **Game Manager** | Add / Edit / Delete games with full form |
| **Hero Slider** | Manage which games appear in the homepage carousel |
| **User Management** | 🆕 Full user list with search, provider badges, order counts |
| → User Detail | Profile card, complete order history, raw JSON data |

---

## 🗂 Project Structure

```
gamestore-enhanced/
├── server/
│   ├── index.js          ← Express API + Razorpay + Firestore
│   └── package.json
└── client/
    ├── src/
    │   ├── pages/
    │   │   ├── Login.js      ← Email + Google OAuth
    │   │   ├── Payment.js    ← Razorpay + UPI/Wallet fallback
    │   │   ├── Admin.js      ← Dashboard + Game Mgr + Users
    │   │   └── ...
    │   └── context/
    │       └── AuthContext.js
    └── package.json
```

---

## 🌐 API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/auth/google` | Save Google OAuth user to Firestore |
| POST | `/api/payment/create-order` | Create Razorpay order |
| POST | `/api/payment/verify` | Verify Razorpay signature + save order |
| GET  | `/api/admin/users` | All users with order stats |
| GET  | `/api/admin/users/:uid` | Single user with full order history |

---

## 🛡 Security Notes

- Razorpay signatures are **verified server-side** using HMAC-SHA256
- Passwords are stored as-is in demo (add bcrypt for production)
- Firebase tokens can be verified server-side using `firebase-admin` for production
- Firestore rules should be tightened before going live
