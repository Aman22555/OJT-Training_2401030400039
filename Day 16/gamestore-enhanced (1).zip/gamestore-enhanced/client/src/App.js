import React, { useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';

import Home        from './pages/Home';
import Login       from './pages/Login';
import AdminLogin  from './pages/AdminLogin';
import Admin       from './pages/Admin';
import GameDetails from './pages/GameDetails';
import Payment     from './pages/Payment';

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/"            element={<Home />} />
            <Route path="/login"       element={<Login />} />
            <Route path="/admin-login" element={<AdminLogin />} />
            <Route path="/admin"       element={<Admin />} />
            <Route path="/game/:id"    element={<GameDetails />} />
            <Route path="/payment"     element={<Payment />} />
            <Route path="*"            element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </AuthProvider>
  );
}
