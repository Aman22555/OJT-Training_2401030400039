import React, { useState, useEffect } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { useToast } from '../context/ToastContext';
import { useAuth } from '../context/AuthContext';

const GAME_IMAGES = {
  'BGMI':'https://i.ytimg.com/vi/-ErnVg5aDag/hq720.jpg',
  'VALORANT':'https://wallpapers.com/images/hd/4k-hd-valorant-1m8v8h6l10gnss81.jpg',
  'Counter-Strike 2':'https://wallpapercave.com/wp/wp12803694.png',
  'Cyberpunk 2077':'https://c4.wallpaperflare.com/wallpaper/943/63/773/cyberpunk-2077-cyberpunk-video-games-wallpaper-preview.jpg',
  'Elden Ring':'https://4kwallpapers.com/images/wallpapers/elden-ring-7680x4320-20173.jpg',
  'God of War Ragnarök':'https://cdn.wallpapersafari.com/15/57/uPNyez.jpg',
  'Forza Horizon 6':'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkRyEPyYuoSnmbQxKf4fCgeMlYhcSqnHvHYQ&s',
};

const inp   = { width:'100%', background:'var(--bg)', border:'1px solid var(--border)', borderRadius:5, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.95rem', padding:'10px 12px', outline:'none', transition:'border-color 0.2s,box-shadow 0.2s' };
const lbl   = { display:'block', fontSize:'0.7rem', textTransform:'uppercase', letterSpacing:1, color:'var(--dim)', marginBottom:6 };
const panel = { background:'var(--card)', border:'1px solid var(--border)', borderRadius:6, overflow:'hidden', marginBottom:20 };
const ph    = { background:'#0d0f12', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--accent)', padding:'14px 20px' };
function focusStyle(e){e.target.style.borderColor='var(--accent)';e.target.style.boxShadow='0 0 0 2px rgba(213,116,84,.15)';}
function blurStyle(e){e.target.style.borderColor='var(--border)';e.target.style.boxShadow='';}

// Load Razorpay checkout script once
function loadRazorpayScript() {
  return new Promise(resolve => {
    if (window.Razorpay) { resolve(true); return; }
    const s = document.createElement('script');
    s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload  = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function Payment() {
  const [params]  = useSearchParams();
  const navigate  = useNavigate();
  const { addToast } = useToast();
  const { user }  = useAuth();

  const gameName  = params.get('game')  || 'Unknown Game';
  const gamePrice = parseFloat(params.get('price') || '0');

  const [method, setMethod]     = useState('razorpay');
  const [promo, setPromo]       = useState('');
  const [discount, setDiscount] = useState(0);
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess]   = useState(null);
  const [step, setStep]         = useState(1);
  const [cardNum, setCardNum]   = useState('');
  const [expiry, setExpiry]     = useState('');
  const [holder, setHolder]     = useState('');
  const [form, setForm]         = useState({ fname:user?.name?.split(' ')[0]||'', lname:user?.name?.split(' ').slice(1).join(' ')||'', email:user?.email||'', phone:'' });

  const tax      = +(gamePrice * 0.18).toFixed(2);
  const subtotal = +(gamePrice * (1 - discount)).toFixed(2);
  const total    = +(subtotal + tax).toFixed(2);
  const gameImg  = GAME_IMAGES[gameName] || `https://placehold.co/400x225/12151a/d57454?text=${encodeURIComponent(gameName)}`;

  function formatCard(val){ const d=val.replace(/\D/g,'').slice(0,16); setCardNum(d.replace(/(.{4})/g,'$1 ').trim()); }
  function formatExpiry(val){ const d=val.replace(/\D/g,'').slice(0,4); setExpiry(d.length>2?`${d.slice(0,2)}/${d.slice(2)}`:d); }

  function applyPromo(){
    if(promo.toUpperCase()==='GAME10'){ setDiscount(0.1); addToast('Promo applied! 10% off 🎉'); }
    else addToast('Invalid promo code','error');
  }

  // ── Razorpay checkout ──────────────────────────────────
  async function handleRazorpay() {
    setProcessing(true);
    const loaded = await loadRazorpayScript();
    if (!loaded) { addToast('Failed to load Razorpay SDK','error'); setProcessing(false); return; }

    try {
      // Create order on server
      const orderRes = await fetch('/api/payment/create-order', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ amount: total, gameId: gameName }),
      });
      const orderData = await orderRes.json();
      if (!orderRes.ok) throw new Error(orderData.error);

      if (orderData.dev) {
        // Dev mode – skip real Razorpay
        addToast('⚠️ Dev mode: Razorpay keys not set. Payment simulated.','error');
        await simulatePayment();
        return;
      }

      const options = {
        key: orderData.key,
        amount: orderData.amount,
        currency: orderData.currency || 'INR',
        name: 'GameStore',
        description: `Purchase: ${gameName}`,
        order_id: orderData.id,
        prefill: { name: `${form.fname} ${form.lname}`.trim(), email: form.email, contact: form.phone },
        theme: { color: '#d57454' },
        handler: async function(response) {
          // Verify signature on server
          const vRes = await fetch('/api/payment/verify', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({
              razorpay_order_id:   response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature:  response.razorpay_signature,
              gameId: gameName, amount: total,
              userId: user?.uid || user?.email || 'guest',
            }),
          });
          const vData = await vRes.json();
          if (vRes.ok) { setSuccess(vData); setStep(3); }
          else addToast(vData.error || 'Payment verification failed','error');
          setProcessing(false);
        },
        modal: {
          ondismiss: () => { addToast('Payment cancelled','error'); setProcessing(false); },
        },
      };
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch(err) {
      addToast(err.message || 'Payment error','error');
      setProcessing(false);
    }
  }

  // ── Mock fallback for UPI / Wallet / demo ─────────────
  async function simulatePayment() {
    setStep(3);
    try {
      const res  = await fetch('/api/payment/process', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ gameId:gameName, method, amount:total, userId:user?.uid||user?.email||'guest' }) });
      const data = await res.json();
      if (res.ok) setSuccess(data);
      else addToast('Payment failed','error');
    } catch { addToast('Server error','error'); }
    setProcessing(false);
  }

  async function processPayment() {
    if (method === 'razorpay') { handleRazorpay(); return; }
    setProcessing(true);
    await simulatePayment();
  }

  async function downloadGame() {
    // Try to find the game's real download file from server
    try {
      const gameId = params.get('gameId') || gameName.toLowerCase().replace(/[^a-z0-9]+/g,'-');
      const res  = await fetch(`/api/games/${gameId}`);
      if (res.ok) {
        const game = await res.json();
        if (game.downloadUrl) {
          const a = document.createElement('a');
          a.href = game.downloadUrl;
          a.download = game.fileName || gameName.replace(/[^a-zA-Z0-9]/g,'_')+'_Setup';
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
          return;
        }
      }
    } catch(_) {}
    // Fallback: generate placeholder
    const lines = ['╔══════════════════════════════════════════╗','║       GameStore – Official Installer      ║','╚══════════════════════════════════════════╝','',`  Game   : ${gameName}`,`  Order  : ${success?.orderId}`,`  Date   : ${new Date().toLocaleDateString('en-IN')}`,'','  Thank you for your purchase!','═══════════════════════════════════════════════','  GameStore © 2025 · All Rights Reserved','═══════════════════════════════════════════════'].join('\r\n');
    const blob = new Blob([lines],{type:'application/octet-stream'});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a'); a.href=url; a.download=gameName.replace(/[^a-zA-Z0-9]/g,'_')+'_Setup.exe';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(()=>URL.revokeObjectURL(url),1500);
  }

  const StepCircle = ({ n }) => (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
      <div style={{ width:32, height:32, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:'0.9rem', background:step>n?'var(--success)':step===n?'var(--accent)':'var(--border)', color:step>=n?'#fff':'var(--dim)', transition:'all 0.3s' }}>{n}</div>
      <div style={{ fontSize:'0.7rem', textTransform:'uppercase', letterSpacing:1, color:step===n?'var(--accent)':'var(--dim)' }}>{['','Details','Payment','Confirm'][n]}</div>
    </div>
  );

  return (
    <>
      {/* ── Success overlay ── */}
      {success && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.85)', zIndex:9999, display:'flex', alignItems:'center', justifyContent:'center' }}>
          <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:12, padding:'50px 40px', textAlign:'center', maxWidth:440, animation:'popIn 0.4s ease' }}>
            <div style={{ fontSize:'3rem', marginBottom:16 }}>🎮</div>
            <h2 style={{ fontFamily:"'Barlow Condensed',sans-serif", color:'var(--success)', fontSize:'2rem', marginBottom:8 }}>Payment Successful!</h2>
            <p style={{ color:'var(--dim)', marginBottom:20 }}>Your purchase of <strong style={{ color:'var(--text)' }}>{gameName}</strong> was completed.</p>
            <div style={{ background:'var(--bg)', border:'1px solid var(--border)', padding:'10px 20px', borderRadius:4, fontFamily:'monospace', color:'var(--accent)', marginBottom:28, display:'inline-block' }}>
              ORDER #{success.orderId}
            </div>
            <div style={{ display:'flex', gap:12, justifyContent:'center' }}>
              <button className="btn-outline" onClick={()=>navigate('/')}>Back to Store</button>
              <button className="btn-accent" onClick={downloadGame}>Download ↓</button>
            </div>
          </div>
          <style>{`@keyframes popIn{from{transform:scale(.8);opacity:0}to{transform:scale(1);opacity:1}}`}</style>
        </div>
      )}

      <nav style={{ background:'#0d0f12', borderBottom:'1px solid var(--border)', padding:'0 24px', height:56, display:'flex', alignItems:'center', justifyContent:'space-between', position:'sticky', top:0, zIndex:200 }}>
        <Link to="/" style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.6rem', fontWeight:900, color:'var(--accent)', letterSpacing:2, display:'flex', alignItems:'center', gap:8 }}>
          <i className="bi bi-controller" /> GameStore
        </Link>
        <div style={{ display:'flex', alignItems:'center', gap:16 }}>
          <span style={{ fontSize:'0.78rem', color:'var(--dim)', display:'flex', alignItems:'center', gap:6 }}>
            <i className="bi bi-shield-check" style={{ color:'var(--success)' }} /> Secured by Razorpay
          </span>
          <button onClick={()=>navigate(-1)} style={{ background:'none', border:'none', color:'var(--dim)', cursor:'pointer', fontWeight:600, fontSize:'0.85rem', textTransform:'uppercase', letterSpacing:1, display:'flex', alignItems:'center', gap:6 }}>
            <i className="bi bi-arrow-left" /> Back
          </button>
        </div>
      </nav>

      <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:0, padding:'28px 20px', maxWidth:500, margin:'0 auto' }}>
        <StepCircle n={1} />
        <div style={{ flex:1, height:2, background:step>1?'var(--success)':'var(--border)', margin:'0 8px', marginBottom:20, transition:'background 0.3s' }} />
        <StepCircle n={2} />
        <div style={{ flex:1, height:2, background:step>2?'var(--success)':'var(--border)', margin:'0 8px', marginBottom:20, transition:'background 0.3s' }} />
        <StepCircle n={3} />
      </div>

      <div style={{ maxWidth:1000, margin:'0 auto', padding:'0 20px 60px', display:'grid', gridTemplateColumns:'1fr 380px', gap:24 }}>
        {/* Left */}
        <div>
          {/* Account details */}
          <div style={panel}>
            <div style={ph}>Account Details</div>
            <div style={{ padding:20 }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:14, marginBottom:14 }}>
                {[['fname','First Name'],['lname','Last Name']].map(([k,l]) => (
                  <div key={k}><label style={lbl}>{l}</label><input style={inp} value={form[k]} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))} onFocus={focusStyle} onBlur={blurStyle} /></div>
                ))}
              </div>
              <div style={{ marginBottom:14 }}><label style={lbl}>Email Address</label><input type="email" style={inp} value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))} placeholder="you@example.com" onFocus={focusStyle} onBlur={blurStyle} /></div>
              <div><label style={lbl}>Phone Number</label><input type="tel" style={inp} value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} placeholder="+91 98765 43210" onFocus={focusStyle} onBlur={blurStyle} /></div>
            </div>
          </div>

          {/* Payment method */}
          <div style={panel}>
            <div style={ph}>Payment Method</div>
            <div style={{ padding:20 }}>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginBottom:20 }}>
                {[
                  ['razorpay','🏦','Razorpay','Recommended'],
                  ['upi','📱','UPI / QR','GPay, PhonePe'],
                  ['wallet','👝','Wallet','Paytm etc.'],
                ].map(([m,ico,lbl2,sub]) => (
                  <div key={m} onClick={()=>{setMethod(m);setStep(2);}}
                    style={{ border:`2px solid ${method===m?'var(--accent)':'var(--border)'}`, borderRadius:6, padding:'12px 8px', textAlign:'center', cursor:'pointer', transition:'all 0.2s', background:method===m?'rgba(213,116,84,.08)':'var(--bg)', position:'relative' }}>
                    {m==='razorpay' && <div style={{ position:'absolute', top:-8, left:'50%', transform:'translateX(-50%)', background:'var(--accent)', color:'#fff', fontSize:'0.55rem', fontWeight:900, letterSpacing:1, padding:'2px 8px', borderRadius:10, textTransform:'uppercase' }}>LIVE</div>}
                    <div style={{ fontSize:'1.5rem' }}>{ico}</div>
                    <div style={{ fontSize:'0.8rem', fontWeight:700, textTransform:'uppercase', color:method===m?'var(--accent)':'var(--dim)', marginTop:4 }}>{lbl2}</div>
                    <div style={{ fontSize:'0.65rem', color:'var(--dim)', marginTop:2 }}>{sub}</div>
                  </div>
                ))}
              </div>

              {method === 'razorpay' && (
                <div style={{ background:'rgba(213,116,84,.05)', border:'1px solid rgba(213,116,84,.2)', borderRadius:8, padding:16 }}>
                  <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
                    <i className="bi bi-shield-check" style={{ color:'var(--success)', fontSize:'1.2rem' }} />
                    <div>
                      <div style={{ fontWeight:700, fontSize:'0.9rem' }}>Razorpay Secure Checkout</div>
                      <div style={{ fontSize:'0.75rem', color:'var(--dim)' }}>Cards · UPI · Net Banking · EMI · Wallets</div>
                    </div>
                  </div>
                  <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
                    {['VISA','Mastercard','RuPay','UPI','GPay','PhonePe','Paytm','BHIM'].map(b=>(
                      <span key={b} style={{ background:'var(--bg)', border:'1px solid var(--border)', padding:'4px 10px', borderRadius:4, fontSize:'0.75rem', fontWeight:700, color:'var(--dim)' }}>{b}</span>
                    ))}
                  </div>
                  <p style={{ fontSize:'0.72rem', color:'var(--dim)', marginTop:12, lineHeight:1.5 }}>
                    Clicking "Pay Now" will open Razorpay's secure payment window.<br/>
                    <strong style={{ color:'var(--text)' }}>Test cards:</strong> 4111 1111 1111 1111 · Expiry: any future · CVV: any 3 digits
                  </p>
                </div>
              )}

              {method === 'upi' && (
                <div>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginBottom:16 }}>
                    {[['🇬','GPay'],['🅿','PhonePe'],['💰','Paytm']].map(([ico,n])=>(
                      <div key={n} style={{ border:'2px solid var(--border)', borderRadius:6, padding:'10px 6px', textAlign:'center', cursor:'pointer', fontSize:'0.85rem', fontWeight:700, color:'var(--dim)', transition:'all 0.2s' }}
                        onMouseEnter={e=>{e.currentTarget.style.borderColor='var(--accent)';e.currentTarget.style.color='var(--accent)';}}
                        onMouseLeave={e=>{e.currentTarget.style.borderColor='var(--border)';e.currentTarget.style.color='var(--dim)';}}>
                        <div style={{ fontSize:'1.5rem' }}>{ico}</div>{n}
                      </div>
                    ))}
                  </div>
                  <label style={lbl}>UPI ID</label>
                  <input style={inp} placeholder="yourname@upi" onFocus={focusStyle} onBlur={blurStyle} />
                  <p style={{ fontSize:'0.72rem', color:'var(--dim)', marginTop:8 }}>⚠️ UPI direct integration requires Razorpay webhook setup. Using mock payment for demo.</p>
                </div>
              )}

              {method === 'wallet' && (
                <div>
                  <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:10, marginBottom:16 }}>
                    {[['💙','Paytm'],['🟣','Amazon Pay'],['🟢','Mobikwik']].map(([ico,n])=>(
                      <div key={n} style={{ border:'2px solid var(--border)', borderRadius:6, padding:'10px 6px', textAlign:'center', cursor:'pointer', fontSize:'0.85rem', fontWeight:700, color:'var(--dim)', transition:'all 0.2s' }}
                        onMouseEnter={e=>{e.currentTarget.style.borderColor='var(--accent)';e.currentTarget.style.color='var(--accent)';}}
                        onMouseLeave={e=>{e.currentTarget.style.borderColor='var(--border)';e.currentTarget.style.color='var(--dim)';}}>
                        <div style={{ fontSize:'1.5rem' }}>{ico}</div>{n}
                      </div>
                    ))}
                  </div>
                  <label style={lbl}>Wallet Phone Number</label>
                  <input type="tel" style={inp} placeholder="+91 98765 43210" onFocus={focusStyle} onBlur={blurStyle} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right – Order summary */}
        <div>
          <div style={panel}>
            <div style={ph}>Order Summary</div>
            <div style={{ padding:20 }}>
              <div style={{ display:'flex', gap:14, paddingBottom:16, marginBottom:16, borderBottom:'1px solid var(--border)' }}>
                <img src={gameImg} alt={gameName} style={{ width:70, height:50, objectFit:'cover', borderRadius:4 }} onError={e=>{e.target.src=`https://placehold.co/70x50/12151a/d57454?text=G`;}} />
                <div>
                  <div style={{ fontWeight:700, marginBottom:4 }}>{gameName}</div>
                  <div style={{ fontSize:'0.78rem', color:'var(--dim)' }}>Digital Download · 1×</div>
                  <div style={{ fontSize:'0.72rem', color:'var(--success)', marginTop:4 }}>✓ Instant delivery after payment</div>
                </div>
              </div>

              <div style={{ display:'flex', gap:8, marginBottom:20 }}>
                <input style={{ ...inp, flex:1 }} placeholder="Promo (try GAME10)" value={promo} onChange={e=>setPromo(e.target.value)} onFocus={focusStyle} onBlur={blurStyle} />
                <button onClick={applyPromo} style={{ background:'var(--border)', color:'var(--dim)', border:'1px solid var(--border)', borderRadius:5, fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.85rem', textTransform:'uppercase', padding:'0 14px', cursor:'pointer', whiteSpace:'nowrap', transition:'all 0.2s' }}
                  onMouseEnter={e=>{e.target.style.background='var(--accent)';e.target.style.color='#fff';}}
                  onMouseLeave={e=>{e.target.style.background='var(--border)';e.target.style.color='var(--dim)';}}>
                  Apply
                </button>
              </div>

              <div style={{ display:'flex', flexDirection:'column', gap:10, marginBottom:16 }}>
                <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.9rem', color:'var(--dim)' }}>
                  <span>Subtotal</span><span>₹{gamePrice.toLocaleString('en-IN')}</span>
                </div>
                {discount > 0 && (
                  <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.9rem', color:'var(--success)' }}>
                    <span>Discount (10%)</span><span>−₹{(gamePrice*0.1).toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div style={{ display:'flex', justifyContent:'space-between', fontSize:'0.9rem', color:'var(--dim)' }}>
                  <span>Tax (18% GST)</span><span>₹{tax.toLocaleString('en-IN')}</span>
                </div>
                <div style={{ display:'flex', justifyContent:'space-between', borderTop:'1px solid var(--border)', paddingTop:12, fontWeight:700, fontSize:'1.1rem' }}>
                  <span>Total</span><span style={{ color:'var(--accent)', fontSize:'1.2rem' }}>₹{total.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <button className="btn-accent" style={{ width:'100%', padding:'14px', fontSize:'1.1rem' }} onClick={processPayment} disabled={processing}>
                {processing ? 'Processing…' : method==='razorpay' ? '🔒 Pay with Razorpay' : '🔒 Pay Now'}
              </button>
              <p style={{ textAlign:'center', marginTop:10, color:'var(--dim)', fontSize:'0.72rem', textTransform:'uppercase', letterSpacing:1 }}>
                Powered by Razorpay · 256-bit SSL
              </p>
            </div>
          </div>

          <div style={{ ...panel, padding:16 }}>
            <div style={{ fontSize:'0.7rem', textTransform:'uppercase', letterSpacing:1, color:'var(--dim)', marginBottom:10 }}>Accepted Payments</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
              {['VISA','Mastercard','RuPay','UPI','GPay','PhonePe','Paytm','EMI'].map(b=>(
                <span key={b} style={{ background:'var(--bg)', border:'1px solid var(--border)', padding:'5px 12px', borderRadius:4, fontSize:'0.8rem', fontWeight:700 }}>{b}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
