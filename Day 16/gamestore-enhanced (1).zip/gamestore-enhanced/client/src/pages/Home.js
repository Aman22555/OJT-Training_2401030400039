import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Carousel from '../components/Carousel';
import GameCard from '../components/GameCard';

export default function Home() {
  const [games, setGames]         = useState([]);
  const [category, setCategory]   = useState('all');
  const [loading, setLoading]     = useState(true);
  const [searchParams]            = useSearchParams();
  const searchQuery               = searchParams.get('search') || '';
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (category && category !== 'all') params.set('category', category);
    if (searchQuery) params.set('search', searchQuery);
    fetch(`/api/games?${params}`)
      .then(r => r.json())
      .then(data => { setGames(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [category, searchQuery]);

  const [allGames, setAllGames] = useState([]);
  useEffect(() => { fetch('/api/games').then(r => r.json()).then(setAllGames).catch(() => {}); }, []);

  const featured  = games.filter(g => g.featured);
  const showCarousel = !searchQuery && category === 'all';

  const CAT_LABELS = { all: 'All Games', 'battle-royale': 'Battle Royale', 'fps-shooter': 'FPS / Shooter', rpg: 'RPG', action: 'Action / Adventure', racing: 'Racing', sports: 'Sports', puzzle: 'Puzzle', simulation: 'Simulation', free: 'Free to Play' };

  function triggerDownload(game) {
    // If admin uploaded a real file, use it directly
    if (game.downloadUrl) {
      const a = document.createElement('a');
      a.href = game.downloadUrl;
      a.download = game.fileName || game.title.replace(/[^a-zA-Z0-9]/g,'_') + '_Setup';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      return;
    }
    // Fallback: generate a placeholder installer text file
    const lines = [
      '╔══════════════════════════════════════════╗',
      '║        GameStore – Official Installer     ║',
      '╚══════════════════════════════════════════╝',
      '', `  Game   : ${game.title}`, `  Version: 1.0.0`, `  Date   : ${new Date().toLocaleDateString('en-IN')}`,
      '', '  This is a FREE game. No payment required.', '  Download and enjoy!',
      '', '══════════════════════════════════════════════', '  GameStore © 2025 · All Rights Reserved', '══════════════════════════════════════════════'
    ].join('\r\n');
    const blob = new Blob([lines], { type: 'application/octet-stream' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = game.title.replace(/[^a-zA-Z0-9]/g, '_') + '_Free_Setup.exe';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  return (
    <>
      <Navbar activeCategory={category} onCategoryChange={setCategory} />

      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '24px 20px' }}>
        {/* Hero Carousel */}
        {showCarousel && allGames.length > 0 && (
          <div style={{ marginBottom: 40 }}>
            <Carousel games={allGames} />
          </div>
        )}

        {/* Active category / search header */}
        {(category !== 'all' || searchQuery) && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <div className="section-title">
              {searchQuery ? `Results for "${searchQuery}"` : CAT_LABELS[category]}
              <span className="section-count">{games.length}</span>
            </div>
            <button className="btn-outline" onClick={() => { setCategory('all'); navigate('/'); }}>
              <i className="bi bi-x me-1" /> Clear
            </button>
          </div>
        )}

        {/* Featured cards */}
        {!searchQuery && category === 'all' && featured.length > 0 && (
          <div style={{ marginBottom: 40 }}>
            <div className="section-title">
              Featured Games <span className="section-count">{featured.length}</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 20 }}>
              {featured.map(g => <GameCard key={g.id} game={g} />)}
            </div>
          </div>
        )}

        {/* All games table */}
        {loading ? (
          <div style={{ textAlign: 'center', padding: 60, color: 'var(--dim)' }}>
            <i className="bi bi-controller" style={{ fontSize: '2rem', color: 'var(--accent)', display: 'block', marginBottom: 12 }} />
            Loading games…
          </div>
        ) : games.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 60, color: 'var(--dim)', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.4rem', letterSpacing: 2, textTransform: 'uppercase' }}>
            <i className="bi bi-search" style={{ fontSize: '2.5rem', color: 'var(--accent)', display: 'block', marginBottom: 12 }} />
            No games found
          </div>
        ) : (
          <div>
            <div className="section-title">
              {category !== 'all' || searchQuery ? '' : 'All Games '}
              {(category === 'all' && !searchQuery) && <span className="section-count">{games.length}</span>}
            </div>
            <div style={{ border: '1px solid var(--border)', borderRadius: 6, background: 'var(--card)', overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', color: 'var(--dim)' }}>
                <thead>
                  <tr style={{ background: 'hsl(220,13%,9%)' }}>
                    {['Game Title', 'Genre', 'Platform', 'Storage', 'Price', 'Action'].map(h => (
                      <th key={h} style={{ color: 'var(--accent)', fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: 1.5, padding: '14px 16px', textAlign: 'left', fontWeight: 700 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {games.map(g => {
                    const isFree = g.price === 0;
                    return (
                      <tr key={g.id}
                        style={{ cursor: 'pointer', borderBottom: '1px solid var(--border)', transition: 'background 0.2s' }}
                        onClick={() => navigate(`/game/${g.id}`)}
                        onMouseEnter={e => { Array.from(e.currentTarget.cells).forEach(c => { c.style.background = '#181c22'; c.style.color = 'var(--text)'; }); }}
                        onMouseLeave={e => { Array.from(e.currentTarget.cells).forEach(c => { c.style.background = ''; c.style.color = ''; }); }}>
                        <td style={{ padding: '12px 16px', verticalAlign: 'middle' }}>
                          <span style={{ color: 'var(--accent)', fontWeight: 700, fontSize: '0.95rem' }}>{g.title}</span>
                          {isFree && <span className="badge-free">FREE</span>}
                        </td>
                        <td style={{ padding: '12px 16px', verticalAlign: 'middle', fontSize: '0.88rem' }}>{g.genre}</td>
                        <td style={{ padding: '12px 16px', verticalAlign: 'middle', fontSize: '0.88rem' }}>{g.platform || 'PC'}</td>
                        <td style={{ padding: '12px 16px', verticalAlign: 'middle', fontSize: '0.82rem' }}>{g.storage || '—'}</td>
                        <td style={{ padding: '12px 16px', verticalAlign: 'middle', fontWeight: 700, color: isFree ? '#27ae60' : 'var(--accent)' }}>
                          {isFree ? 'FREE' : '₹' + g.price.toLocaleString('en-IN')}
                        </td>
                        <td style={{ padding: '12px 16px', verticalAlign: 'middle' }} onClick={e => e.stopPropagation()}>
                          {isFree
                            ? <button style={{ background: '#27ae60', color: '#fff', border: 'none', padding: '6px 14px', fontWeight: 700, fontSize: '0.8rem', textTransform: 'uppercase', cursor: 'pointer', borderRadius: 3 }} onClick={() => triggerDownload(g)}>Download</button>
                            : <button style={{ background: 'var(--accent)', color: '#fff', border: 'none', padding: '6px 14px', fontWeight: 700, fontSize: '0.8rem', textTransform: 'uppercase', cursor: 'pointer', borderRadius: 3 }} onClick={() => navigate(`/payment?game=${encodeURIComponent(g.title)}&price=${g.price}`)}>Buy</button>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      <footer style={{ textAlign: 'center', padding: 30, color: 'var(--dim)', fontSize: '0.8rem', borderTop: '1px solid var(--border)', marginTop: 40 }}>
        © 2025 GameStore. All rights reserved. · All prices in INR.
        <a href="/admin-login" style={{ marginLeft: 16, color: 'var(--dim)', opacity: 0.5, fontSize: '0.72rem' }}>Admin Panel</a>
      </footer>
    </>
  );
}
