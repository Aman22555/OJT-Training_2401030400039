import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

// ── Firebase Google Auth ──────────────────────────────────
// Replace the config values below with your Firebase project's config.
// Firebase console → Project Settings → Your apps → Web app → SDK snippet
const FIREBASE_CONFIG = {
  apiKey:            process.env.REACT_APP_FIREBASE_API_KEY            || 'YOUR_API_KEY',
  authDomain:        process.env.REACT_APP_FIREBASE_AUTH_DOMAIN        || 'your-app.firebaseapp.com',
  projectId:         process.env.REACT_APP_FIREBASE_PROJECT_ID         || 'your-project-id',
  storageBucket:     process.env.REACT_APP_FIREBASE_STORAGE_BUCKET     || 'your-app.appspot.com',
  messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID|| '000000000000',
  appId:             process.env.REACT_APP_FIREBASE_APP_ID             || '1:000:web:000',
};

// Lazy-load Firebase so the app works even without the SDK
let _firebaseApp = null, _auth = null, _googleProvider = null;
async function getFirebase() {
  if (_auth) return { auth: _auth, provider: _googleProvider };
  try {
    const { initializeApp, getApps } = await import('firebase/app');
    const { getAuth, GoogleAuthProvider } = await import('firebase/auth');
    if (!getApps().length) _firebaseApp = initializeApp(FIREBASE_CONFIG);
    _auth = getAuth(_firebaseApp);
    _googleProvider = new GoogleAuthProvider();
    return { auth: _auth, provider: _googleProvider };
  } catch (err) {
    throw new Error('Firebase SDK not loaded. Run: npm install firebase');
  }
}

function StrengthBar({ pw }) {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw)) score++; if (/[0-9]/.test(pw)) score++; if (/[^A-Za-z0-9]/.test(pw)) score++;
  const levels = [
    { w:'20%', c:'#e74c3c', t:'Weak' },{ w:'45%', c:'#e8b84b', t:'Fair' },
    { w:'70%', c:'#3498db', t:'Good' },{ w:'100%', c:'#4caf8a', t:'Strong ✓' },
  ];
  const l = levels[Math.min(score-1,3)] || levels[0];
  if (!pw) return null;
  return (
    <div style={{ marginTop:8 }}>
      <div style={{ height:3, background:'var(--border)', borderRadius:2, overflow:'hidden' }}>
        <div style={{ height:'100%', width:l.w, background:l.c, borderRadius:2, transition:'width 0.3s,background 0.3s' }} />
      </div>
      <div style={{ fontSize:'0.72rem', color:l.c, marginTop:4 }}>{l.t}</div>
    </div>
  );
}

const INTERESTS = ['Battle Royale','Puzzle','Shooter','Action','Stealth','RPG','Sports','Indie'];

export default function Login() {
  const [tab, setTab]         = useState('login');
  const [showPw, setShowPw]   = useState(false);
  const [showPw2, setShowPw2] = useState(false);
  const [interests, setInterests] = useState([]);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  const [loginData,  setLoginData]  = useState({ username:'', password:'' });
  const [signupData, setSignupData] = useState({ name:'', email:'', password:'' });

  const { login } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const inputStyle = { width:'100%', background:'var(--card)', border:'1px solid var(--border)', borderRadius:5, color:'var(--text)', fontFamily:"'Rajdhani', sans-serif", fontSize:'1rem', padding:'11px 14px', outline:'none', transition:'border-color 0.2s,box-shadow 0.2s' };
  const labelStyle = { display:'block', fontSize:'0.7rem', textTransform:'uppercase', letterSpacing:1, color:'var(--dim)', marginBottom:6 };

  async function handleLogin(e) {
    e.preventDefault(); setLoading(true);
    try {
      const res  = await fetch('/api/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ username:loginData.username, password:loginData.password }) });
      const data = await res.json();
      if (res.ok) {
        login(data.user, data.role === 'admin');
        addToast(data.role === 'admin' ? 'Admin login successful!' : 'Welcome back! 🎮');
        setTimeout(() => navigate(data.role === 'admin' ? '/admin' : '/'), 1200);
      } else addToast(data.error || 'Invalid credentials', 'error');
    } catch { addToast('Server error', 'error'); }
    setLoading(false);
  }

  async function handleSignup(e) {
    e.preventDefault(); setLoading(true);
    try {
      const res  = await fetch('/api/auth/signup', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ ...signupData, interests }) });
      const data = await res.json();
      if (res.ok) { login(data.user, false); addToast('Account created! Welcome 🎮'); setTimeout(() => navigate('/'), 1500); }
      else addToast(data.error || 'Signup failed', 'error');
    } catch { addToast('Server error', 'error'); }
    setLoading(false);
  }

  async function handleGoogleLogin() {
    setGoogleLoading(true);
    try {
      const { auth, provider } = await getFirebase();
      const { signInWithPopup } = await import('firebase/auth');
      const result = await signInWithPopup(auth, provider);
      const fbUser = result.user;
      // Save / update user in our backend (Firestore via server)
      const res = await fetch('/api/auth/google', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          uid: fbUser.uid,
          email: fbUser.email,
          name: fbUser.displayName,
          photoURL: fbUser.photoURL,
          provider: 'google',
        }),
      });
      const data = await res.json();
      if (res.ok) {
        login(data.user, false);
        addToast('Signed in with Google! 🎮');
        setTimeout(() => navigate('/'), 1200);
      } else addToast(data.error || 'Google sign-in failed', 'error');
    } catch (err) {
      if (err.code === 'auth/popup-closed-by-user') addToast('Google sign-in cancelled', 'error');
      else addToast(err.message || 'Google sign-in failed', 'error');
    }
    setGoogleLoading(false);
  }

  const GoogleBtn = ({ label }) => (
    <button type="button" onClick={handleGoogleLogin} disabled={googleLoading}
      style={{ width:'100%', padding:'11px 14px', background:'#fff', border:'1px solid #dadce0', borderRadius:5, display:'flex', alignItems:'center', justifyContent:'center', gap:10, cursor:googleLoading?'wait':'pointer', fontFamily:"'Rajdhani', sans-serif", fontWeight:700, fontSize:'0.95rem', color:'#3c4043', transition:'all 0.2s', marginBottom:16 }}
      onMouseEnter={e => e.currentTarget.style.boxShadow='0 1px 3px rgba(0,0,0,.2)'}
      onMouseLeave={e => e.currentTarget.style.boxShadow=''}>
      {googleLoading
        ? <span style={{color:'#555'}}>Signing in…</span>
        : <>
            <svg width="20" height="20" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.2l6.7-6.7C35.8 2.6 30.2 0 24 0 14.6 0 6.7 5.5 2.7 13.5l7.8 6.1C12.4 13.1 17.8 9.5 24 9.5z"/>
              <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.2-.4-4.7H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 6.9-10.1 7.1-17.3z"/>
              <path fill="#FBBC05" d="M10.5 28.4c-.6-1.7-.9-3.5-.9-5.4s.3-3.7.9-5.4L2.7 11.5C1 14.9 0 18.8 0 23s1 8.1 2.7 11.5l7.8-6.1z"/>
              <path fill="#34A853" d="M24 48c6.2 0 11.4-2 15.2-5.5l-7.5-5.8c-2.1 1.4-4.7 2.2-7.7 2.2-6.2 0-11.5-4.2-13.5-9.8l-7.8 6.1C6.7 42.5 14.6 48 24 48z"/>
            </svg>
            {label}
          </>
      }
    </button>
  );

  const Divider = () => (
    <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16 }}>
      <div style={{ flex:1, height:1, background:'var(--border)' }} />
      <span style={{ fontSize:'0.72rem', color:'var(--dim)', textTransform:'uppercase', letterSpacing:1 }}>or</span>
      <div style={{ flex:1, height:1, background:'var(--border)' }} />
    </div>
  );

  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', minHeight:'100vh' }}>
      {/* Left brand panel */}
      <div style={{ background:'linear-gradient(135deg,#0c0f14,#101418,#13181f)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', justifyContent:'center', padding:'60px 48px', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', width:500, height:500, background:'radial-gradient(circle,rgba(213,116,84,.07),transparent 70%)', top:-100, left:-100, borderRadius:'50%' }} />
        <div style={{ position:'relative', zIndex:1 }}>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'2.4rem', fontWeight:900, color:'var(--accent)', letterSpacing:3, display:'flex', alignItems:'center', gap:12, marginBottom:8 }}>
            <i className="bi bi-controller" /> GAMESTORE
          </div>
          <p style={{ color:'var(--dim)', marginBottom:40 }}>Your ultimate gaming destination.</p>
          {[
            { icon:'bi-lightning-charge-fill', title:'Instant Digital Delivery', desc:'Get your games instantly after purchase.' },
            { icon:'bi-shield-check', title:'Secure Payments via Razorpay', desc:'UPI, cards, wallets — all accepted with bank-level encryption.' },
            { icon:'bi-google', title:'Sign in with Google', desc:'One-click login using your Google account.' },
            { icon:'bi-trophy-fill', title:'Rewards & Loyalty Points', desc:'Earn GCoins on every purchase.' },
          ].map(f => (
            <div key={f.title} style={{ display:'flex', gap:16, alignItems:'flex-start', marginBottom:24 }}>
              <div style={{ width:42, height:42, borderRadius:10, background:'rgba(213,116,84,.12)', border:'1px solid rgba(213,116,84,.25)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--accent)', flexShrink:0 }}>
                <i className={`bi ${f.icon}`} />
              </div>
              <div>
                <div style={{ fontWeight:700, marginBottom:4 }}>{f.title}</div>
                <div style={{ fontSize:'0.82rem', color:'var(--dim)', lineHeight:1.4 }}>{f.desc}</div>
              </div>
            </div>
          ))}
          <div style={{ display:'flex', gap:32, marginTop:16 }}>
            {[['500K+','Players'],['10K+','Games'],['4.9★','Rating']].map(([v,l]) => (
              <div key={l}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.8rem', fontWeight:800, color:'var(--accent)', letterSpacing:1 }}>{v}</div>
                <div style={{ fontSize:'0.75rem', color:'var(--dim)', textTransform:'uppercase', letterSpacing:1 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right form panel */}
      <div style={{ display:'flex', flexDirection:'column', justifyContent:'center', padding:'40px 48px', overflowY:'auto' }}>
        {/* Tab switcher */}
        <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:6, padding:4, display:'flex', marginBottom:28 }}>
          {['login','signup'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{ flex:1, background:tab===t?'var(--accent)':'none', border:'none', color:tab===t?'#fff':'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.85rem', textTransform:'uppercase', letterSpacing:1, padding:9, borderRadius:4, cursor:'pointer', transition:'all 0.2s' }}>
              {t==='login'?'Sign In':'Create Account'}
            </button>
          ))}
        </div>

        <div style={{ marginBottom:20 }}>
          <h2 style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'2rem', fontWeight:800, textTransform:'uppercase', marginBottom:4 }}>
            {tab==='login'?'Welcome Back!':'Join GameStore'}
          </h2>
          <p style={{ color:'var(--dim)', fontSize:'0.9rem' }}>
            {tab==='login'?'Sign in to access your game library.':'Create your free account and start playing today.'}
          </p>
        </div>

        {/* Google Sign-In button */}
        <GoogleBtn label={tab==='login'?'Continue with Google':'Sign up with Google'} />
        <Divider />

        {tab === 'login' ? (
          <form onSubmit={handleLogin}>
            <div style={{ marginBottom:16 }}>
              <label style={labelStyle}>Username or Email</label>
              <div style={{ position:'relative' }}>
                <i className="bi bi-person" style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'var(--dim)' }} />
                <input style={{ ...inputStyle, paddingLeft:38 }} value={loginData.username} onChange={e => setLoginData(d=>({...d,username:e.target.value}))} placeholder="Username or email" required
                  onFocus={e=>{e.target.style.borderColor='var(--accent)';e.target.style.boxShadow='0 0 0 3px rgba(213,116,84,.12)';}}
                  onBlur={e=>{e.target.style.borderColor='var(--border)';e.target.style.boxShadow='';}} />
              </div>
            </div>
            <div style={{ marginBottom:20 }}>
              <label style={labelStyle}>Password</label>
              <div style={{ position:'relative' }}>
                <i className="bi bi-lock" style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'var(--dim)' }} />
                <input type={showPw?'text':'password'} style={{ ...inputStyle, paddingLeft:38, paddingRight:38 }} value={loginData.password} onChange={e=>setLoginData(d=>({...d,password:e.target.value}))} placeholder="Password" required
                  onFocus={e=>{e.target.style.borderColor='var(--accent)';e.target.style.boxShadow='0 0 0 3px rgba(213,116,84,.12)';}}
                  onBlur={e=>{e.target.style.borderColor='var(--border)';e.target.style.boxShadow='';}} />
                <button type="button" onClick={()=>setShowPw(v=>!v)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', color:'var(--dim)', cursor:'pointer' }}>
                  <i className={`bi ${showPw?'bi-eye-slash':'bi-eye'}`} />
                </button>
              </div>
            </div>
            <button type="submit" className="btn-accent" style={{ width:'100%', padding:'13px', marginBottom:20 }} disabled={loading}>
              {loading?'…':<><i className="bi bi-box-arrow-in-right me-2" /> Sign In</>}
            </button>
          </form>
        ) : (
          <form onSubmit={handleSignup}>
            <div style={{ marginBottom:14 }}>
              <label style={labelStyle}>Full Name</label>
              <div style={{ position:'relative' }}>
                <i className="bi bi-person" style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'var(--dim)' }} />
                <input style={{ ...inputStyle, paddingLeft:38 }} value={signupData.name} onChange={e=>setSignupData(d=>({...d,name:e.target.value}))} placeholder="Your full name" required
                  onFocus={e=>{e.target.style.borderColor='var(--accent)';e.target.style.boxShadow='0 0 0 3px rgba(213,116,84,.12)';}}
                  onBlur={e=>{e.target.style.borderColor='var(--border)';e.target.style.boxShadow='';}} />
              </div>
            </div>
            <div style={{ marginBottom:14 }}>
              <label style={labelStyle}>Email Address</label>
              <div style={{ position:'relative' }}>
                <i className="bi bi-envelope" style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'var(--dim)' }} />
                <input type="email" style={{ ...inputStyle, paddingLeft:38 }} value={signupData.email} onChange={e=>setSignupData(d=>({...d,email:e.target.value}))} placeholder="your@email.com" required
                  onFocus={e=>{e.target.style.borderColor='var(--accent)';e.target.style.boxShadow='0 0 0 3px rgba(213,116,84,.12)';}}
                  onBlur={e=>{e.target.style.borderColor='var(--border)';e.target.style.boxShadow='';}} />
              </div>
            </div>
            <div style={{ marginBottom:16 }}>
              <label style={labelStyle}>Password</label>
              <div style={{ position:'relative' }}>
                <i className="bi bi-lock" style={{ position:'absolute', left:13, top:'50%', transform:'translateY(-50%)', color:'var(--dim)' }} />
                <input type={showPw2?'text':'password'} style={{ ...inputStyle, paddingLeft:38, paddingRight:38 }} value={signupData.password} onChange={e=>setSignupData(d=>({...d,password:e.target.value}))} placeholder="Choose a strong password" required
                  onFocus={e=>{e.target.style.borderColor='var(--accent)';e.target.style.boxShadow='0 0 0 3px rgba(213,116,84,.12)';}}
                  onBlur={e=>{e.target.style.borderColor='var(--border)';e.target.style.boxShadow='';}} />
                <button type="button" onClick={()=>setShowPw2(v=>!v)} style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', color:'var(--dim)', cursor:'pointer' }}>
                  <i className={`bi ${showPw2?'bi-eye-slash':'bi-eye'}`} />
                </button>
              </div>
              <StrengthBar pw={signupData.password} />
            </div>
            <div style={{ marginBottom:20 }}>
              <label style={labelStyle}>Choose Your Interests</label>
              <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
                {INTERESTS.map(i => (
                  <span key={i} onClick={()=>setInterests(arr=>arr.includes(i)?arr.filter(x=>x!==i):[...arr,i])}
                    style={{ cursor:'pointer', background:interests.includes(i)?'rgba(213,116,84,.1)':'var(--card)', border:`1px solid ${interests.includes(i)?'var(--accent)':'var(--border)'}`, padding:'5px 12px', borderRadius:20, fontSize:'0.78rem', color:interests.includes(i)?'var(--accent)':'var(--dim)', fontWeight:600, textTransform:'uppercase', transition:'all 0.2s', userSelect:'none' }}>
                    {i}
                  </span>
                ))}
              </div>
            </div>
            <button type="submit" className="btn-accent" style={{ width:'100%', padding:'13px', marginBottom:20 }} disabled={loading}>
              {loading?'…':<><i className="bi bi-person-check-fill me-2" /> Create My Account</>}
            </button>
          </form>
        )}

        <div style={{ textAlign:'center', marginTop:8 }}>
          <Link to="/" style={{ color:'var(--dim)', fontSize:'0.78rem', textTransform:'uppercase', letterSpacing:1 }}>
            <i className="bi bi-arrow-left me-1" /> Back to Store
          </Link>
        </div>
      </div>
    </div>
  );
}
