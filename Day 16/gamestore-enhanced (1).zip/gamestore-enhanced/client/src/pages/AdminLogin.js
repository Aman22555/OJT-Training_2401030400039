import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export default function AdminLogin() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw]     = useState(false);
  const [loading, setLoading]   = useState(false);
  const { login } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const res  = await fetch('/api/auth/admin-login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }) });
      const data = await res.json();
      if (res.ok) {
        login(data.user, true);
        addToast('Admin access granted!');
        setTimeout(() => navigate('/admin'), 900);
      } else {
        addToast(data.error || 'Access denied.', 'error');
        setPassword('');
      }
    } catch { addToast('Server error', 'error'); }
    setLoading(false);
  }

  const inp = { width: '100%', background: '#0a0d12', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text)', fontFamily: "'Rajdhani', sans-serif", fontSize: '1rem', fontWeight: 500, padding: '12px 14px 12px 42px', outline: 'none', transition: 'border-color 0.2s, box-shadow 0.2s' };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', position: 'relative' }}>
      {/* Animated grid */}
      <div style={{ position: 'fixed', inset: 0, zIndex: 0, backgroundImage: 'linear-gradient(rgba(213,116,84,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(213,116,84,.04) 1px,transparent 1px)', backgroundSize: '48px 48px', animation: 'gridShift 20s linear infinite' }} />
      <div style={{ position: 'fixed', width: 600, height: 600, background: 'radial-gradient(circle,rgba(213,116,84,.08),transparent 70%)', top: -200, left: -200, borderRadius: '50%', filter: 'blur(80px)', zIndex: 0 }} />
      <div style={{ position: 'fixed', width: 400, height: 400, background: 'radial-gradient(circle,rgba(213,116,84,.05),transparent 70%)', bottom: -100, right: -100, borderRadius: '50%', filter: 'blur(80px)', zIndex: 0 }} />

      <style>{`@keyframes gridShift { to { background-position: 48px 48px; } }`}</style>

      <div style={{ position: 'relative', zIndex: 10, width: '100%', maxWidth: 420, padding: 16 }}>
        {/* Brand */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '2.2rem', fontWeight: 900, color: 'var(--accent)', letterSpacing: 4, textTransform: 'uppercase', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}>
            <i className="bi bi-controller" /> GameStore
          </div>
          <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: 3, color: 'var(--dim)', marginTop: 6 }}>Management Portal</div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: 'rgba(213,116,84,.1)', border: '1px solid rgba(213,116,84,.3)', color: 'var(--accent)', fontSize: '0.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 2, padding: '4px 14px', borderRadius: 20, marginTop: 10 }}>
            <i className="bi bi-shield-lock-fill" /> Admin Access Only
          </div>
        </div>

        {/* Card */}
        <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 10, padding: '36px 32px', boxShadow: '0 24px 64px rgba(0,0,0,.5)' }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.5rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 4 }}>Admin Sign In</div>
          <div style={{ fontSize: '0.82rem', color: 'var(--dim)', marginBottom: 28 }}>Restricted area — authorised personnel only</div>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 18 }}>
              <label style={{ display: 'block', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: 1.5, color: 'var(--dim)', marginBottom: 8 }}>Admin Username</label>
              <div style={{ position: 'relative' }}>
                <input style={inp} value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter admin username" required
                  onFocus={e => { e.target.style.borderColor = 'var(--accent)'; e.target.style.boxShadow = '0 0 0 3px rgba(213,116,84,.12)'; }}
                  onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.boxShadow = ''; }} />
                <i className="bi bi-person-badge" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--dim)', pointerEvents: 'none' }} />
              </div>
            </div>

            <div style={{ marginBottom: 24 }}>
              <label style={{ display: 'block', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: 1.5, color: 'var(--dim)', marginBottom: 8 }}>Password</label>
              <div style={{ position: 'relative' }}>
                <input type={showPw ? 'text' : 'password'} style={{ ...inp, paddingRight: 42 }} value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter admin password" required
                  onFocus={e => { e.target.style.borderColor = 'var(--accent)'; e.target.style.boxShadow = '0 0 0 3px rgba(213,116,84,.12)'; }}
                  onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.boxShadow = ''; }} />
                <i className="bi bi-lock" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', color: 'var(--dim)', pointerEvents: 'none' }} />
                <button type="button" onClick={() => setShowPw(v => !v)} style={{ position: 'absolute', right: 14, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--dim)', cursor: 'pointer', fontSize: '1rem' }}>
                  <i className={`bi ${showPw ? 'bi-eye-slash' : 'bi-eye'}`} />
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} style={{ width: '100%', padding: 14, background: loading ? 'rgba(213,116,84,.7)' : 'var(--accent)', border: 'none', borderRadius: 6, color: '#fff', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.1rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 2, cursor: loading ? 'not-allowed' : 'pointer', transition: 'background 0.2s, box-shadow 0.2s', marginTop: 8 }}
              onMouseEnter={e => { if (!loading) { e.target.style.background = '#bf5f40'; e.target.style.boxShadow = '0 0 24px rgba(213,116,84,.3)'; } }}
              onMouseLeave={e => { e.target.style.background = loading ? 'rgba(213,116,84,.7)' : 'var(--accent)'; e.target.style.boxShadow = ''; }}>
              {loading
                ? <span style={{ display: 'inline-block', width: 18, height: 18, border: '2px solid rgba(255,255,255,.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin .6s linear infinite' }} />
                : <><i className="bi bi-shield-check" style={{ marginRight: 8 }} />Access Admin Panel</>}
            </button>
          </form>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 20, fontSize: '0.75rem', color: 'var(--dim)' }}>
            <Link to="/" style={{ color: 'var(--dim)', transition: 'color 0.2s' }}
              onMouseEnter={e => e.target.style.color = 'var(--accent)'}
              onMouseLeave={e => e.target.style.color = 'var(--dim)'}>
              <i className="bi bi-arrow-left" style={{ marginRight: 4 }} />Back to Store
            </Link>
            <span>GameStore © 2025</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '12px 16px', background: 'rgba(28,33,48,.5)', border: '1px solid var(--border)', borderRadius: 6, marginTop: 20, fontSize: '0.73rem', color: 'var(--dim)' }}>
            <i className="bi bi-info-circle-fill" style={{ color: 'var(--accent)', flexShrink: 0 }} />
            <span>All admin actions are logged. Unauthorised access is prohibited.</span>
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
