import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

const CATEGORIES = ['battle-royale','fps-shooter','rpg','action','racing','sports','puzzle','simulation'];

const inp = { width: '100%', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text)', fontFamily: "'Rajdhani', sans-serif", fontSize: '0.95rem', padding: '10px 13px', outline: 'none', transition: 'border-color 0.2s' };
const lbl = { display: 'block', fontSize: '0.68rem', textTransform: 'uppercase', letterSpacing: 1.5, color: 'var(--dim)', marginBottom: 7 };

function StatCard({ value, label, icon, color }) {
  const colors = { orange: 'var(--accent)', green: 'var(--success)', blue: 'var(--info)', yellow: 'var(--warn)' };
  const c = colors[color] || 'var(--accent)';
  return (
    <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, padding: 20, position: 'relative', overflow: 'hidden', borderTop: `2px solid ${c}` }}>
      <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '2.2rem', fontWeight: 800, lineHeight: 1, color: c }}>{value}</div>
      <div style={{ fontSize: '0.72rem', textTransform: 'uppercase', letterSpacing: 1, color: 'var(--dim)', marginTop: 4 }}>{label}</div>
      <i className={`bi ${icon}`} style={{ position: 'absolute', right: 16, top: 16, fontSize: '1.6rem', opacity: 0.15, color: c }} />
    </div>
  );
}

function GameModal({ game, onClose, onSave }) {
  const [form, setForm] = useState(game || { id: '', title: '', genre: '', category: 'action', platform: 'PC', storage: '', price: '', img: '', featured: false, inSlider: false });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 2000, background: 'rgba(0,0,0,.7)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 10, width: '100%', maxWidth: 560, maxHeight: '90vh', overflowY: 'auto', boxShadow: '0 32px 80px rgba(0,0,0,.6)' }}>
        <div style={{ padding: '20px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, background: 'var(--card)', zIndex: 1 }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.2rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2 }}>
            {game ? 'Edit Game' : 'Add New Game'}
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--dim)', cursor: 'pointer', fontSize: '1.2rem' }}><i className="bi bi-x" /></button>
        </div>
        <div style={{ padding: 24 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
            <div><label style={lbl}>Game ID (slug)</label><input style={inp} value={form.id} onChange={e => set('id', e.target.value.toLowerCase().replace(/\s+/g,'-'))} placeholder="e.g. my-game" onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} /></div>
            <div><label style={lbl}>Title</label><input style={inp} value={form.title} onChange={e => set('title', e.target.value)} placeholder="Game Title" onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} /></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
            <div><label style={lbl}>Genre</label><input style={inp} value={form.genre} onChange={e => set('genre', e.target.value)} placeholder="e.g. Action RPG" onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} /></div>
            <div>
              <label style={lbl}>Category</label>
              <select style={{ ...inp, cursor: 'pointer' }} value={form.category} onChange={e => set('category', e.target.value)} onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'}>
                {CATEGORIES.map(c => <option key={c} value={c}>{c.replace('-',' ')}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginBottom: 14 }}>
            <div><label style={lbl}>Platform</label><input style={inp} value={form.platform} onChange={e => set('platform', e.target.value)} placeholder="PC" onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} /></div>
            <div><label style={lbl}>Storage</label><input style={inp} value={form.storage} onChange={e => set('storage', e.target.value)} placeholder="e.g. 50GB" onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} /></div>
            <div><label style={lbl}>Price (₹)</label><input type="number" style={inp} value={form.price} onChange={e => set('price', Number(e.target.value))} placeholder="0 = Free" min={0} onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} /></div>
          </div>
          <div style={{ marginBottom: 14 }}>
            <label style={lbl}>Image URL</label>
            <input style={inp} value={form.img} onChange={e => set('img', e.target.value)} placeholder="https://…" onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
          </div>
          <div style={{ display: 'flex', gap: 20, paddingTop: 8 }}>
            {[['featured','Featured Game'],['inSlider','Show in Hero Slider']].map(([k,l]) => (
              <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: '0.85rem', color: 'var(--dim)' }}>
                <input type="checkbox" checked={!!form[k]} onChange={e => set(k, e.target.checked)} style={{ accentColor: 'var(--accent)', width: 15, height: 15 }} />
                {l}
              </label>
            ))}
          </div>
        </div>
        <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'flex-end', gap: 10, position: 'sticky', bottom: 0, background: 'var(--card)' }}>
          <button onClick={onClose} style={{ padding: '9px 18px', background: 'none', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--dim)', fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: '0.9rem', textTransform: 'uppercase', cursor: 'pointer' }}>Cancel</button>
          <button onClick={() => onSave(form)} className="btn-accent" style={{ padding: '9px 18px' }}>
            <i className={`bi ${game ? 'bi-check2' : 'bi-plus-lg'}`} /> {game ? 'Save Changes' : 'Add Game'}
          </button>
        </div>
      </div>
    </div>
  );
}

function ConfirmDialog({ title, msg, onConfirm, onCancel }) {
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 3000, background: 'rgba(0,0,0,.75)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 10, padding: 28, maxWidth: 380, width: '100%', margin: 20, textAlign: 'center', boxShadow: '0 24px 64px rgba(0,0,0,.6)' }}>
        <i className="bi bi-exclamation-triangle-fill" style={{ fontSize: '2.5rem', color: 'var(--danger)', display: 'block', marginBottom: 12 }} />
        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.3rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 8 }}>{title}</div>
        <div style={{ fontSize: '0.88rem', color: 'var(--dim)', marginBottom: 24 }}>{msg}</div>
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <button onClick={onCancel} style={{ padding: '9px 24px', background: 'none', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--dim)', fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, textTransform: 'uppercase', cursor: 'pointer' }}>Cancel</button>
          <button onClick={onConfirm} style={{ padding: '9px 24px', background: 'var(--danger)', border: 'none', borderRadius: 6, color: '#fff', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, textTransform: 'uppercase', cursor: 'pointer' }}>Delete</button>
        </div>
      </div>
    </div>
  );
}

export default function Admin() {
  const { user, isAdmin, logout } = useAuth();
  const { addToast } = useToast();
  const navigate = useNavigate();

  const [activePage, setActivePage] = useState('dashboard');
  const [users, setUsers]             = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [userSearch, setUserSearch]   = useState('');
  const [usersLoaded, setUsersLoaded] = useState(false);
  const [filesList, setFilesList]     = useState([]);
  const [uploadingId, setUploadingId] = useState(null);
  const [uploadProgress, setUploadProgress] = useState({});
  const [settings, setSettings]       = useState(null);
  const [settingsSaving, setSettingsSaving] = useState(false);
  const [games, setGames]           = useState([]);
  const [stats, setStats]           = useState(null);
  const [search, setSearch]         = useState('');
  const [catFilter, setCatFilter]   = useState('all');
  const [modal, setModal]           = useState(null); // null | 'add' | gameObj
  const [confirm, setConfirm]       = useState(null); // null | gameId

  // Redirect if not admin
  useEffect(() => { if (!isAdmin) navigate('/admin-login'); }, [isAdmin, navigate]);

  const loadGames = useCallback(() => {
    fetch('/api/games').then(r => r.json()).then(setGames).catch(() => {});
  }, []);

  const loadStats = useCallback(() => {
    fetch('/api/admin/stats').then(r => r.json()).then(setStats).catch(() => {});
  }, []);

  useEffect(() => { loadGames(); loadStats(); }, [loadGames, loadStats]);

  const loadUsers = useCallback(() => {
    setUsersLoaded(false);
    fetch('/api/admin/users').then(r => r.json()).then(u => { setUsers(Array.isArray(u) ? u : []); setUsersLoaded(true); }).catch(() => setUsersLoaded(true));
  }, []);

  useEffect(() => { if (activePage === 'users') loadUsers(); }, [activePage, loadUsers]);

  const loadFiles = useCallback(() => {
    fetch('/api/admin/files').then(r => r.json()).then(d => setFilesList(d.gamesWithFiles || [])).catch(() => {});
  }, []);
  useEffect(() => { if (activePage === 'files') loadFiles(); }, [activePage, loadFiles]);

  const loadSettings = useCallback(() => {
    fetch('/api/settings').then(r => r.json()).then(setSettings).catch(() => {});
  }, []);
  useEffect(() => { if (activePage === 'settings' && !settings) loadSettings(); }, [activePage, settings, loadSettings]);

  async function saveSettings() {
    setSettingsSaving(true);
    try {
      const res = await fetch('/api/settings', { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(settings) });
      const data = await res.json();
      setSettings(data);
      addToast('Settings saved! ✓');
    } catch { addToast('Failed to save settings', 'error'); }
    setSettingsSaving(false);
  }

  async function uploadFile(gameId, file) {
    setUploadingId(gameId);
    setUploadProgress(p => ({...p, [gameId]: 0}));
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res  = await fetch(`/api/games/${gameId}/upload`, { method: 'POST', body: formData });
      const data = await res.json();
      if (res.ok) { addToast(`File uploaded for ${gameId} ✓`); loadGames(); loadFiles(); }
      else addToast(data.error || 'Upload failed', 'error');
    } catch { addToast('Upload error', 'error'); }
    setUploadingId(null);
    setUploadProgress(p => { const n={...p}; delete n[gameId]; return n; });
  }

  async function removeFile(gameId) {
    const res = await fetch(`/api/games/${gameId}/upload`, { method: 'DELETE' });
    if (res.ok) { addToast('File removed'); loadGames(); loadFiles(); }
    else addToast('Remove failed', 'error');
  }

  async function saveGame(form) {
    const isEdit = modal && modal !== 'add';
    const url    = isEdit ? `/api/games/${form.id}` : '/api/games';
    const method = isEdit ? 'PUT' : 'POST';
    const res    = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    if (res.ok) { loadGames(); loadStats(); addToast(isEdit ? 'Game updated!' : 'Game added!'); setModal(null); }
    else addToast('Failed to save game', 'error');
  }

  async function deleteGame(id) {
    const res = await fetch(`/api/games/${id}`, { method: 'DELETE' });
    if (res.ok) { loadGames(); loadStats(); addToast('Game deleted'); }
    else addToast('Delete failed', 'error');
    setConfirm(null);
  }

  async function toggleSlider(game) {
    await fetch(`/api/games/${game.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...game, inSlider: !game.inSlider }) });
    loadGames(); addToast(game.inSlider ? 'Removed from slider' : 'Added to slider');
  }

  const filtered = games.filter(g => {
    const q = search.toLowerCase();
    const matchSearch = !q || g.title.toLowerCase().includes(q) || g.genre.toLowerCase().includes(q);
    const matchCat    = catFilter === 'all' || g.category === catFilter;
    return matchSearch && matchCat;
  });

  const sliderGames    = games.filter(g => g.inSlider);
  const nonSliderGames = games.filter(g => !g.inSlider);

  const NAV = [
    { id: 'dashboard', icon: 'bi-speedometer2', label: 'Dashboard'       },
    { id: 'games',     icon: 'bi-controller',   label: 'Game Manager'    },
    { id: 'files',     icon: 'bi-cloud-upload',  label: 'Game Files'      },
    { id: 'slider',    icon: 'bi-images',        label: 'Hero Slider'     },
    { id: 'users',     icon: 'bi-people-fill',   label: 'User Management' },
    { id: 'settings',  icon: 'bi-gear-fill',     label: 'Site Settings'   },
  ];

  const sidebarItemStyle = (active) => ({
    display: 'flex', alignItems: 'center', gap: 10, padding: '11px 20px', fontSize: '0.9rem', fontWeight: 600,
    color: active ? 'var(--accent)' : 'var(--dim)', textTransform: 'uppercase', letterSpacing: 0.5,
    cursor: 'pointer', transition: 'all 0.2s', borderLeft: `3px solid ${active ? 'var(--accent)' : 'transparent'}`,
    background: active ? 'rgba(213,116,84,.12)' : 'transparent', textDecoration: 'none',
  });

  if (!isAdmin) return null;

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {modal && <GameModal game={modal === 'add' ? null : modal} onClose={() => setModal(null)} onSave={saveGame} />}
      {confirm && <ConfirmDialog title="Delete Game" msg={`Are you sure you want to delete "${confirm.title}"? This cannot be undone.`} onConfirm={() => deleteGame(confirm.id)} onCancel={() => setConfirm(null)} />}

      {/* Sidebar */}
      <aside style={{ position: 'fixed', top: 0, left: 0, height: '100vh', width: 240, background: 'var(--sidebar-bg)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', zIndex: 1000 }}>
        <div style={{ padding: '22px 20px 18px', borderBottom: '1px solid var(--border)' }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.4rem', fontWeight: 900, color: 'var(--accent)', letterSpacing: 3, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8 }}>
            <i className="bi bi-controller" /> GameStore
          </div>
          <div style={{ fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: 2, color: 'var(--dim)', marginTop: 4 }}>Admin Panel</div>
        </div>

        <nav style={{ flex: 1, padding: '16px 0', overflowY: 'auto' }}>
          <div style={{ fontSize: '0.6rem', textTransform: 'uppercase', letterSpacing: 2, color: 'var(--dim)', padding: '8px 20px 6px' }}>Main</div>
          {NAV.map(n => (
            <div key={n.id} style={sidebarItemStyle(activePage === n.id)} onClick={() => setActivePage(n.id)}>
              <i className={`bi ${n.icon}`} style={{ width: 20, textAlign: 'center', fontSize: '1rem' }} />
              {n.label}
              {n.id === 'games' && <span style={{ marginLeft: 'auto', background: 'var(--accent)', color: '#fff', fontSize: '0.6rem', fontWeight: 700, padding: '2px 7px', borderRadius: 10 }}>{games.length}</span>}
              {n.id === 'users' && <span style={{ marginLeft: 'auto', background: 'rgba(59,130,246,.8)', color: '#fff', fontSize: '0.6rem', fontWeight: 700, padding: '2px 7px', borderRadius: 10 }}>{stats?.totalUsers || users.length}</span>}
            </div>
          ))}
          <div style={{ fontSize: '0.6rem', textTransform: 'uppercase', letterSpacing: 2, color: 'var(--dim)', padding: '16px 20px 6px' }}>Store</div>
          <Link to="/" style={sidebarItemStyle(false)}>
            <i className="bi bi-shop" style={{ width: 20, textAlign: 'center', fontSize: '1rem' }} /> View Store
          </Link>
        </nav>

        <div style={{ padding: '16px 20px', borderTop: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: 'rgba(213,116,84,.12)', border: '1px solid rgba(213,116,84,.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--accent)' }}>
              <i className="bi bi-person-badge" />
            </div>
            <div>
              <div style={{ fontSize: '0.85rem', fontWeight: 700 }}>{user?.name || 'Admin'}</div>
              <div style={{ fontSize: '0.65rem', color: 'var(--dim)', textTransform: 'uppercase', letterSpacing: 1 }}>Administrator</div>
            </div>
            <button onClick={() => { logout(); navigate('/'); }} title="Logout" style={{ marginLeft: 'auto', background: 'none', border: 'none', color: 'var(--dim)', cursor: 'pointer', fontSize: '1rem', padding: 4, transition: 'color 0.2s' }}
              onMouseEnter={e => e.target.style.color = 'var(--danger)'}
              onMouseLeave={e => e.target.style.color = 'var(--dim)'}>
              <i className="bi bi-box-arrow-right" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div style={{ marginLeft: 240, minHeight: '100vh', flex: 1, display: 'flex', flexDirection: 'column' }}>
        {/* Topbar */}
        <div style={{ position: 'sticky', top: 0, zIndex: 100, background: 'rgba(7,9,12,.9)', backdropFilter: 'blur(12px)', borderBottom: '1px solid var(--border)', padding: '14px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.3rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2 }}>
            {NAV.find(n => n.id === activePage)?.label || 'Admin'}{activePage==='users' && <span style={{marginLeft:12,background:'rgba(213,116,84,.15)',border:'1px solid rgba(213,116,84,.3)',color:'var(--accent)',fontSize:'0.65rem',fontWeight:700,padding:'2px 10px',borderRadius:10}}>{users.length} users</span>}
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 16px', background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--dim)', fontSize: '0.82rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, transition: 'all 0.2s' }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--accent)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--dim)'}>
              <i className="bi bi-shop" /> View Store
            </Link>
          </div>
        </div>

        <div style={{ padding: 28, flex: 1 }}>

          {/* ── DASHBOARD ── */}
          {activePage === 'dashboard' && (
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 28 }}>
                <StatCard value={stats?.totalGames ?? '—'}   label="Total Games"   icon="bi-controller"    color="orange" />
                <StatCard value={stats?.freeGames ?? '—'}    label="Free Games"    icon="bi-gift-fill"     color="green"  />
                <StatCard value={stats?.paidGames ?? '—'}    label="Paid Games"    icon="bi-bag-fill"      color="blue"   />
                <StatCard value={stats ? `₹${(stats.avgPrice||0).toLocaleString('en-IN')}` : '—'} label="Avg Price" icon="bi-currency-rupee" color="yellow" />
                <StatCard value={stats?.ordersToday ?? '—'}  label="Orders Today"  icon="bi-receipt"       color="orange" />
                <StatCard value={stats ? `₹${(stats.revenue||0).toLocaleString('en-IN')}` : '—'} label="Revenue"   icon="bi-graph-up-arrow" color="green"  />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
                {/* Recent games */}
                <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '1rem', textTransform: 'uppercase', letterSpacing: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    Recent Games
                    <button onClick={() => setActivePage('games')} style={{ background: 'none', border: 'none', color: 'var(--accent)', fontSize: '0.75rem', cursor: 'pointer', fontWeight: 700, textTransform: 'uppercase' }}>View All</button>
                  </div>
                  <div>
                    {games.slice(0, 6).map(g => (
                      <div key={g.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 18px', borderBottom: '1px solid var(--border)' }}>
                        <img src={g.img} alt={g.title} style={{ width: 52, height: 38, objectFit: 'cover', borderRadius: 4 }} onError={e => { e.target.src = `https://placehold.co/52x38/12151a/d57454?text=G`; }} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{g.title}</div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--dim)', textTransform: 'uppercase' }}>{g.genre}</div>
                        </div>
                        <div style={{ fontWeight: 700, color: g.price === 0 ? 'var(--success)' : 'var(--accent)', fontSize: '0.9rem' }}>
                          {g.price === 0 ? 'FREE' : '₹' + g.price.toLocaleString('en-IN')}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Category breakdown */}
                <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '1rem', textTransform: 'uppercase', letterSpacing: 1.5 }}>
                    Category Breakdown
                  </div>
                  <div style={{ padding: 18 }}>
                    {CATEGORIES.map(cat => {
                      const count = games.filter(g => g.category === cat).length;
                      const pct   = games.length ? Math.round((count / games.length) * 100) : 0;
                      return (
                        <div key={cat} style={{ marginBottom: 14 }}>
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: 5 }}>
                            <span style={{ color: 'var(--text)', fontWeight: 600, textTransform: 'capitalize' }}>{cat.replace('-',' ')}</span>
                            <span style={{ color: 'var(--dim)' }}>{count} games · {pct}%</span>
                          </div>
                          <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, overflow: 'hidden' }}>
                            <div style={{ height: '100%', width: `${pct}%`, background: 'var(--accent)', borderRadius: 2, transition: 'width 0.5s' }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── GAME MANAGER ── */}
          {activePage === 'games' && (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.1rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, paddingLeft: 12, borderLeft: '3px solid var(--accent)' }}>
                  All Games <span style={{ background: 'rgba(213,116,84,.15)', border: '1px solid rgba(213,116,84,.3)', color: 'var(--accent)', fontSize: '0.65rem', fontWeight: 700, padding: '2px 10px', borderRadius: 10, marginLeft: 8 }}>{filtered.length}</span>
                </div>
                <button onClick={() => setModal('add')} className="btn-accent" style={{ display: 'inline-flex', alignItems: 'center', gap: 7, padding: '9px 18px' }}>
                  <i className="bi bi-plus-lg" /> Add Game
                </button>
              </div>

              <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
                {/* Search + filter bar */}
                <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 10 }}>
                  <input style={{ flex: 1, background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--text)', fontFamily: "'Rajdhani', sans-serif", fontSize: '0.9rem', padding: '8px 14px', outline: 'none' }}
                    placeholder="Search games…" value={search} onChange={e => setSearch(e.target.value)}
                    onFocus={e => e.target.style.borderColor = 'var(--accent)'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'} />
                  <select style={{ background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 6, color: 'var(--dim)', fontFamily: "'Rajdhani', sans-serif", fontSize: '0.85rem', padding: '8px 12px', outline: 'none', cursor: 'pointer' }}
                    value={catFilter} onChange={e => setCatFilter(e.target.value)}>
                    <option value="all">All Categories</option>
                    {CATEGORIES.map(c => <option key={c} value={c}>{c.replace('-',' ')}</option>)}
                  </select>
                </div>

                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={{ background: '#0a0d11' }}>
                        {['Game','Genre','Category','Price','Storage','Featured','Actions'].map(h => (
                          <th key={h} style={{ color: 'var(--accent)', fontSize: '0.68rem', textTransform: 'uppercase', letterSpacing: 1.5, padding: '12px 16px', textAlign: 'left', borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filtered.map(g => (
                        <tr key={g.id} style={{ transition: 'background 0.2s' }}
                          onMouseEnter={e => Array.from(e.currentTarget.cells).forEach(c => c.style.background = 'rgba(255,255,255,.02)')}
                          onMouseLeave={e => Array.from(e.currentTarget.cells).forEach(c => c.style.background = '')}>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                              <img src={g.img} alt={g.title} style={{ width: 52, height: 38, objectFit: 'cover', borderRadius: 4 }} onError={e => { e.target.src = `https://placehold.co/52x38/12151a/d57454?text=G`; }} />
                              <div style={{ color: 'var(--text)', fontWeight: 700, fontSize: '0.95rem' }}>{g.title}</div>
                            </div>
                          </td>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle', color: 'var(--dim)', fontSize: '0.88rem' }}>{g.genre}</td>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle' }}>
                            <span className={`badge-cat ${g.category}`}>{g.category.replace('-',' ')}</span>
                          </td>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle', fontWeight: 700, color: g.price === 0 ? 'var(--success)' : 'var(--accent)', fontSize: '0.9rem' }}>
                            {g.price === 0 ? 'FREE' : '₹' + g.price.toLocaleString('en-IN')}
                          </td>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle', color: 'var(--dim)', fontSize: '0.85rem' }}>{g.storage || '—'}</td>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle', textAlign: 'center' }}>
                            <i className={`bi ${g.featured ? 'bi-star-fill' : 'bi-star'}`} style={{ color: g.featured ? 'var(--warn)' : 'var(--border)' }} />
                          </td>
                          <td style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)', verticalAlign: 'middle' }}>
                            <div style={{ display: 'flex', gap: 6 }}>
                              <button onClick={() => setModal(g)} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 10px', background: 'none', border: '1px solid var(--border)', borderRadius: 5, color: 'var(--dim)', fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', cursor: 'pointer', transition: 'all 0.2s' }}
                                onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; e.currentTarget.style.color = 'var(--accent)'; }}
                                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.color = 'var(--dim)'; }}>
                                <i className="bi bi-pencil" /> Edit
                              </button>
                              <button onClick={() => setConfirm(g)} style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 10px', background: 'none', border: '1px solid rgba(224,82,82,.3)', borderRadius: 5, color: 'var(--danger)', fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', cursor: 'pointer', transition: 'all 0.2s' }}
                                onMouseEnter={e => e.currentTarget.style.background = 'rgba(224,82,82,.1)'}
                                onMouseLeave={e => e.currentTarget.style.background = 'none'}>
                                <i className="bi bi-trash" /> Del
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {filtered.length === 0 && (
                  <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--dim)', fontFamily: "'Barlow Condensed', sans-serif", textTransform: 'uppercase', letterSpacing: 2 }}>
                    No games found
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ── USERS ── */}
          {activePage === 'users' && (
            <div>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.1rem', fontWeight:800, textTransform:'uppercase', letterSpacing:2, paddingLeft:12, borderLeft:'3px solid var(--accent)' }}>
                  Registered Users
                </div>
                <button onClick={loadUsers} style={{ background:'none', border:'1px solid var(--border)', borderRadius:6, color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.8rem', textTransform:'uppercase', padding:'7px 14px', cursor:'pointer', display:'flex', alignItems:'center', gap:6 }}>
                  <i className="bi bi-arrow-clockwise" /> Refresh
                </button>
              </div>

              {selectedUser ? (
                /* ── USER DETAIL VIEW ── */
                <div>
                  <button onClick={() => setSelectedUser(null)} style={{ background:'none', border:'none', color:'var(--accent)', cursor:'pointer', fontWeight:700, fontSize:'0.85rem', textTransform:'uppercase', letterSpacing:1, display:'flex', alignItems:'center', gap:6, marginBottom:20, padding:0 }}>
                    <i className="bi bi-arrow-left" /> Back to All Users
                  </button>
                  <div style={{ display:'grid', gridTemplateColumns:'340px 1fr', gap:20 }}>
                    {/* Profile card */}
                    <div>
                      <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden', marginBottom:16 }}>
                        <div style={{ background:'linear-gradient(135deg,rgba(213,116,84,.2),rgba(213,116,84,.05))', padding:'28px 24px', textAlign:'center', borderBottom:'1px solid var(--border)' }}>
                          {selectedUser.photoURL
                            ? <img src={selectedUser.photoURL} alt="" style={{ width:72, height:72, borderRadius:'50%', border:'3px solid var(--accent)', marginBottom:12, display:'block', margin:'0 auto 12px' }} />
                            : <div style={{ width:72, height:72, borderRadius:'50%', background:'var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'1.8rem', fontWeight:900, color:'#fff', margin:'0 auto 12px' }}>{(selectedUser.name||'?')[0].toUpperCase()}</div>
                          }
                          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.4rem', fontWeight:800 }}>{selectedUser.name || 'Unknown'}</div>
                          <div style={{ fontSize:'0.8rem', color:'var(--dim)' }}>{selectedUser.email}</div>
                          <div style={{ marginTop:8 }}>
                            <span style={{ background:selectedUser.status==='active'?'rgba(76,175,138,.15)':'rgba(224,82,82,.1)', border:`1px solid ${selectedUser.status==='active'?'rgba(76,175,138,.4)':'rgba(224,82,82,.4)'}`, color:selectedUser.status==='active'?'var(--success)':'var(--danger)', fontSize:'0.7rem', fontWeight:700, padding:'3px 12px', borderRadius:20, textTransform:'uppercase', letterSpacing:1 }}>
                              {selectedUser.status || 'active'}
                            </span>
                          </div>
                        </div>
                        <div style={{ padding:20 }}>
                          {[
                            ['bi-person-badge','Provider', selectedUser.provider || 'email'],
                            ['bi-calendar3','Joined', selectedUser.createdAt ? new Date(selectedUser.createdAt).toLocaleDateString('en-IN',{year:'numeric',month:'long',day:'numeric'}) : 'Unknown'],
                            ['bi-clock-history','Last Login', selectedUser.lastLogin ? new Date(selectedUser.lastLogin).toLocaleDateString('en-IN') : 'Unknown'],
                            ['bi-bag-check','Orders', selectedUser.orderCount || (selectedUser.orders?.length) || 0],
                            ['bi-currency-rupee','Total Spent', '₹' + ((selectedUser.totalSpent || selectedUser.orders?.reduce((s,o)=>s+(Number(o.amount)||0),0) || 0).toLocaleString('en-IN'))],
                          ].map(([icon,label2,val]) => (
                            <div key={label2} style={{ display:'flex', alignItems:'center', gap:12, padding:'10px 0', borderBottom:'1px solid var(--border)' }}>
                              <i className={`bi ${icon}`} style={{ color:'var(--accent)', width:20, textAlign:'center' }} />
                              <div style={{ flex:1 }}>
                                <div style={{ fontSize:'0.65rem', textTransform:'uppercase', letterSpacing:1, color:'var(--dim)' }}>{label2}</div>
                                <div style={{ fontWeight:700, fontSize:'0.9rem', textTransform: label2==='Provider'?'capitalize':'none' }}>{String(val)}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Orders + details */}
                    <div>
                      <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden', marginBottom:16 }}>
                        <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                          Order History
                          <span style={{ background:'rgba(213,116,84,.12)', border:'1px solid rgba(213,116,84,.3)', color:'var(--accent)', fontSize:'0.65rem', fontWeight:700, padding:'2px 10px', borderRadius:10 }}>{(selectedUser.orders||[]).length} orders</span>
                        </div>
                        {(selectedUser.orders||[]).length === 0
                          ? <div style={{ padding:'30px 20px', textAlign:'center', color:'var(--dim)' }}>No orders yet</div>
                          : (selectedUser.orders||[]).map((o,i) => (
                              <div key={i} style={{ display:'flex', alignItems:'center', gap:16, padding:'12px 20px', borderBottom:'1px solid var(--border)' }}>
                                <div style={{ width:36, height:36, borderRadius:8, background:'rgba(213,116,84,.1)', border:'1px solid rgba(213,116,84,.25)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--accent)', flexShrink:0 }}>
                                  <i className="bi bi-bag-check" />
                                </div>
                                <div style={{ flex:1 }}>
                                  <div style={{ fontWeight:700, fontSize:'0.9rem' }}>{o.gameId}</div>
                                  <div style={{ fontSize:'0.72rem', color:'var(--dim)' }}>
                                    {o.createdAt ? new Date(o.createdAt).toLocaleDateString('en-IN',{year:'numeric',month:'short',day:'numeric'}) : '—'} · {o.method || 'razorpay'}
                                  </div>
                                </div>
                                <div style={{ textAlign:'right' }}>
                                  <div style={{ fontWeight:700, color:'var(--accent)' }}>₹{Number(o.amount||0).toLocaleString('en-IN')}</div>
                                  <div style={{ fontSize:'0.65rem', color:'var(--success)', fontWeight:700, textTransform:'uppercase' }}>PAID</div>
                                </div>
                                <div style={{ fontFamily:'monospace', fontSize:'0.72rem', color:'var(--dim)', flexShrink:0 }}>{o.orderId}</div>
                              </div>
                            ))
                        }
                      </div>

                      {/* Raw data */}
                      <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden' }}>
                        <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5 }}>
                          Full Profile Data
                        </div>
                        <pre style={{ margin:0, padding:20, fontSize:'0.75rem', color:'var(--dim)', overflowX:'auto', fontFamily:"'Courier New',monospace", lineHeight:1.6, maxHeight:280, overflowY:'auto' }}>
                          {JSON.stringify({...selectedUser, orders:undefined, password:undefined}, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* ── USER LIST ── */
                <div>
                  <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden' }}>
                    <div style={{ padding:'14px 16px', borderBottom:'1px solid var(--border)', display:'flex', alignItems:'center', gap:10 }}>
                      <input style={{ flex:1, background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.9rem', padding:'8px 14px', outline:'none' }}
                        placeholder="Search users by name or email…" value={userSearch} onChange={e=>setUserSearch(e.target.value)}
                        onFocus={e=>e.target.style.borderColor='var(--accent)'}
                        onBlur={e=>e.target.style.borderColor='var(--border)'} />
                    </div>

                    {!usersLoaded
                      ? <div style={{ padding:'40px 20px', textAlign:'center', color:'var(--dim)' }}><i className="bi bi-arrow-clockwise" style={{ animation:'spin 1s linear infinite', marginRight:8 }} />Loading users…</div>
                      : users.length === 0
                      ? <div style={{ padding:'40px 20px', textAlign:'center' }}>
                          <i className="bi bi-people" style={{ fontSize:'3rem', color:'var(--dim)', display:'block', marginBottom:12 }} />
                          <div style={{ color:'var(--dim)', fontFamily:"'Barlow Condensed',sans-serif", textTransform:'uppercase', letterSpacing:2 }}>No registered users yet</div>
                          <div style={{ fontSize:'0.8rem', color:'var(--dim)', marginTop:8 }}>Users appear here after they sign up or log in with Google.</div>
                        </div>
                      : <>
                          <div style={{ overflowX:'auto' }}>
                            <table style={{ width:'100%', borderCollapse:'collapse' }}>
                              <thead>
                                <tr style={{ background:'#0a0d11' }}>
                                  {['User','Email','Provider','Status','Orders','Spent','Joined','Actions'].map(h=>(
                                    <th key={h} style={{ color:'var(--accent)', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, padding:'12px 16px', textAlign:'left', borderBottom:'1px solid var(--border)', whiteSpace:'nowrap' }}>{h}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {users.filter(u => {
                                  const q = userSearch.toLowerCase();
                                  return !q || (u.name||'').toLowerCase().includes(q) || (u.email||'').toLowerCase().includes(q);
                                }).map((u,i) => (
                                  <tr key={u.id||u.uid||i} style={{ transition:'background 0.2s', cursor:'pointer' }}
                                    onMouseEnter={e=>Array.from(e.currentTarget.cells).forEach(c=>c.style.background='rgba(255,255,255,.02)')}
                                    onMouseLeave={e=>Array.from(e.currentTarget.cells).forEach(c=>c.style.background='')}>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                                      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                                        {u.photoURL
                                          ? <img src={u.photoURL} alt="" style={{ width:34, height:34, borderRadius:'50%', flexShrink:0 }} />
                                          : <div style={{ width:34, height:34, borderRadius:'50%', background:'rgba(213,116,84,.15)', border:'1px solid rgba(213,116,84,.3)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--accent)', fontWeight:800, fontSize:'0.9rem', flexShrink:0 }}>{(u.name||'?')[0].toUpperCase()}</div>
                                        }
                                        <div style={{ fontWeight:700, fontSize:'0.9rem' }}>{u.name || 'Unknown'}</div>
                                      </div>
                                    </td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', color:'var(--dim)', fontSize:'0.85rem' }}>{u.email}</td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                                      <span style={{ background: u.provider==='google'?'rgba(66,133,244,.12)':'rgba(213,116,84,.1)', border:`1px solid ${u.provider==='google'?'rgba(66,133,244,.4)':'rgba(213,116,84,.3)'}`, color:u.provider==='google'?'#4285f4':'var(--accent)', fontSize:'0.68rem', fontWeight:700, padding:'2px 10px', borderRadius:12, textTransform:'uppercase', letterSpacing:0.5, display:'inline-flex', alignItems:'center', gap:4 }}>
                                        {u.provider==='google'?<><svg width="10" height="10" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.2l6.7-6.7C35.8 2.6 30.2 0 24 0 14.6 0 6.7 5.5 2.7 13.5l7.8 6.1C12.4 13.1 17.8 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.2-.4-4.7H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 6.9-10.1 7.1-17.3z"/><path fill="#FBBC05" d="M10.5 28.4c-.6-1.7-.9-3.5-.9-5.4s.3-3.7.9-5.4L2.7 11.5C1 14.9 0 18.8 0 23s1 8.1 2.7 11.5l7.8-6.1z"/><path fill="#34A853" d="M24 48c6.2 0 11.4-2 15.2-5.5l-7.5-5.8c-2.1 1.4-4.7 2.2-7.7 2.2-6.2 0-11.5-4.2-13.5-9.8l-7.8 6.1C6.7 42.5 14.6 48 24 48z"/></svg>Google</>:'Email'}
                                      </span>
                                    </td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                                      <span style={{ background:u.status==='active'||!u.status?'rgba(76,175,138,.12)':'rgba(224,82,82,.1)', border:`1px solid ${u.status==='active'||!u.status?'rgba(76,175,138,.4)':'rgba(224,82,82,.4)'}`, color:u.status==='active'||!u.status?'var(--success)':'var(--danger)', fontSize:'0.68rem', fontWeight:700, padding:'2px 10px', borderRadius:12, textTransform:'uppercase' }}>
                                        {u.status || 'active'}
                                      </span>
                                    </td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', textAlign:'center', fontWeight:700 }}>{u.orderCount || 0}</td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', color:'var(--accent)', fontWeight:700 }}>
                                      ₹{Number(u.totalSpent||0).toLocaleString('en-IN')}
                                    </td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', color:'var(--dim)', fontSize:'0.8rem', whiteSpace:'nowrap' }}>
                                      {u.createdAt ? new Date(u.createdAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '—'}
                                    </td>
                                    <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                                      <button onClick={() => {
                                        const uid = u.uid || u.id || u.email;
                                        fetch(`/api/admin/users/${encodeURIComponent(uid)}`).then(r=>r.json()).then(d=>setSelectedUser({...u,...d})).catch(()=>setSelectedUser(u));
                                      }} style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'5px 12px', background:'rgba(213,116,84,.1)', border:'1px solid rgba(213,116,84,.3)', borderRadius:5, color:'var(--accent)', fontSize:'0.75rem', fontWeight:700, textTransform:'uppercase', cursor:'pointer', transition:'all 0.2s' }}
                                        onMouseEnter={e=>e.currentTarget.style.background='rgba(213,116,84,.2)'}
                                        onMouseLeave={e=>e.currentTarget.style.background='rgba(213,116,84,.1)'}>
                                        <i className="bi bi-eye" /> View
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                          {users.filter(u=>{const q=userSearch.toLowerCase();return !q||(u.name||'').toLowerCase().includes(q)||(u.email||'').toLowerCase().includes(q);}).length===0 && (
                            <div style={{ textAlign:'center', padding:'30px', color:'var(--dim)' }}>No users match your search</div>
                          )}
                        </>
                    }
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── GAME FILES ── */}
          {activePage === 'files' && (
            <div>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.1rem', fontWeight:800, textTransform:'uppercase', letterSpacing:2, paddingLeft:12, borderLeft:'3px solid var(--accent)' }}>
                  Game File Manager
                </div>
                <div style={{ fontSize:'0.78rem', color:'var(--dim)', background:'var(--card)', border:'1px solid var(--border)', borderRadius:6, padding:'8px 14px' }}>
                  <i className="bi bi-info-circle" style={{ marginRight:6, color:'var(--accent)' }} />
                  Upload installer / zip files. Users download after purchase.
                </div>
              </div>

              {/* Files summary */}
              {filesList.length > 0 && (
                <div style={{ background:'var(--card)', border:'1px solid rgba(76,175,138,.3)', borderRadius:8, padding:'14px 20px', marginBottom:20, display:'flex', alignItems:'center', gap:16 }}>
                  <i className="bi bi-cloud-check-fill" style={{ fontSize:'1.5rem', color:'var(--success)' }} />
                  <div>
                    <div style={{ fontWeight:700 }}>{filesList.length} game{filesList.length!==1?'s':''} have download files attached</div>
                    <div style={{ fontSize:'0.78rem', color:'var(--dim)' }}>
                      Total: {(filesList.reduce((s,f)=>s+(f.fileSize||0),0)/1024/1024).toFixed(1)} MB uploaded
                    </div>
                  </div>
                </div>
              )}

              {/* Game list with upload/download controls */}
              <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden' }}>
                <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', display:'flex', gap:10 }}>
                  <input style={{ flex:1, background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.9rem', padding:'8px 14px', outline:'none' }}
                    placeholder="Search games…" value={search} onChange={e=>setSearch(e.target.value)}
                    onFocus={e=>e.target.style.borderColor='var(--accent)'}
                    onBlur={e=>e.target.style.borderColor='var(--border)'} />
                  <select style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.85rem', padding:'8px 12px', outline:'none' }}
                    onChange={e => {
                      const v = e.target.value;
                      // filter handled inline below
                    }}>
                    <option value="all">All Games</option>
                    <option value="has-file">Has File</option>
                    <option value="no-file">No File</option>
                  </select>
                </div>
                <div style={{ overflowX:'auto' }}>
                  <table style={{ width:'100%', borderCollapse:'collapse' }}>
                    <thead>
                      <tr style={{ background:'#0a0d11' }}>
                        {['Game','Price','Current File','File Size','Actions'].map(h=>(
                          <th key={h} style={{ color:'var(--accent)', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, padding:'12px 16px', textAlign:'left', borderBottom:'1px solid var(--border)', whiteSpace:'nowrap' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {games.filter(g=>!search||g.title.toLowerCase().includes(search.toLowerCase())).map(g => {
                        const hasFile = !!g.downloadFile;
                        const isUploading = uploadingId === g.id;
                        return (
                          <tr key={g.id} style={{ transition:'background 0.2s' }}
                            onMouseEnter={e=>Array.from(e.currentTarget.cells).forEach(c=>c.style.background='rgba(255,255,255,.02)')}
                            onMouseLeave={e=>Array.from(e.currentTarget.cells).forEach(c=>c.style.background='')}>
                            <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                                <img src={g.img} alt="" style={{ width:52, height:36, objectFit:'cover', borderRadius:4 }} onError={e=>{e.target.src=`https://placehold.co/52x36/12151a/d57454?text=G`;}} />
                                <div>
                                  <div style={{ fontWeight:700, fontSize:'0.9rem' }}>{g.title}</div>
                                  <div style={{ fontSize:'0.7rem', color:'var(--dim)', textTransform:'uppercase' }}>{g.genre}</div>
                                </div>
                              </div>
                            </td>
                            <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', fontWeight:700, color:g.price===0?'var(--success)':'var(--accent)' }}>
                              {g.price===0?'FREE':'₹'+g.price.toLocaleString('en-IN')}
                            </td>
                            <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                              {hasFile
                                ? <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                                    <i className="bi bi-file-earmark-zip-fill" style={{ color:'var(--success)', fontSize:'1.1rem' }} />
                                    <div>
                                      <div style={{ fontSize:'0.82rem', fontWeight:600, color:'var(--text)' }}>{g.fileName || g.downloadFile}</div>
                                      <div style={{ fontSize:'0.68rem', color:'var(--success)' }}>✓ Ready to download</div>
                                    </div>
                                  </div>
                                : <span style={{ color:'var(--dim)', fontSize:'0.82rem', display:'flex', alignItems:'center', gap:6 }}>
                                    <i className="bi bi-dash-circle" style={{ color:'rgba(224,82,82,.6)' }} /> No file uploaded
                                  </span>
                              }
                              {isUploading && (
                                <div style={{ marginTop:6, height:3, background:'var(--border)', borderRadius:2, overflow:'hidden' }}>
                                  <div style={{ height:'100%', width:'60%', background:'var(--accent)', borderRadius:2, animation:'pulse 1s infinite' }} />
                                </div>
                              )}
                            </td>
                            <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle', color:'var(--dim)', fontSize:'0.82rem' }}>
                              {g.fileSize ? (g.fileSize/1024/1024).toFixed(1)+' MB' : '—'}
                            </td>
                            <td style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', verticalAlign:'middle' }}>
                              <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
                                {/* Upload button */}
                                <label style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'5px 12px', background:'rgba(213,116,84,.1)', border:'1px solid rgba(213,116,84,.3)', borderRadius:5, color:'var(--accent)', fontSize:'0.75rem', fontWeight:700, textTransform:'uppercase', cursor: isUploading?'wait':'pointer', transition:'all 0.2s', opacity:isUploading?0.6:1 }}
                                  onMouseEnter={e=>!isUploading&&(e.currentTarget.style.background='rgba(213,116,84,.2)')}
                                  onMouseLeave={e=>e.currentTarget.style.background='rgba(213,116,84,.1)'}>
                                  <i className={`bi ${isUploading?'bi-arrow-clockwise':'bi-cloud-upload'}`} style={{animation:isUploading?'spin 1s linear infinite':''}} />
                                  {isUploading?'Uploading…':hasFile?'Replace':'Upload'}
                                  <input type="file" style={{ display:'none' }} disabled={isUploading}
                                    onChange={e => { if(e.target.files[0]) uploadFile(g.id, e.target.files[0]); e.target.value=''; }} />
                                </label>

                                {/* Download preview */}
                                {hasFile && (
                                  <a href={`/api/games/${g.id}/download`} download
                                    style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'5px 12px', background:'rgba(76,175,138,.08)', border:'1px solid rgba(76,175,138,.3)', borderRadius:5, color:'var(--success)', fontSize:'0.75rem', fontWeight:700, textTransform:'uppercase', textDecoration:'none', transition:'all 0.2s' }}
                                    onMouseEnter={e=>e.currentTarget.style.background='rgba(76,175,138,.15)'}
                                    onMouseLeave={e=>e.currentTarget.style.background='rgba(76,175,138,.08)'}>
                                    <i className="bi bi-download" /> Test
                                  </a>
                                )}

                                {/* Remove */}
                                {hasFile && (
                                  <button onClick={()=>removeFile(g.id)}
                                    style={{ display:'inline-flex', alignItems:'center', gap:5, padding:'5px 10px', background:'none', border:'1px solid rgba(224,82,82,.3)', borderRadius:5, color:'var(--danger)', fontSize:'0.75rem', fontWeight:700, textTransform:'uppercase', cursor:'pointer', transition:'all 0.2s' }}
                                    onMouseEnter={e=>e.currentTarget.style.background='rgba(224,82,82,.1)'}
                                    onMouseLeave={e=>e.currentTarget.style.background='none'}>
                                    <i className="bi bi-trash" /> Remove
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ── SITE SETTINGS ── */}
          {activePage === 'settings' && settings && (
            <div>
              <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:20 }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.1rem', fontWeight:800, textTransform:'uppercase', letterSpacing:2, paddingLeft:12, borderLeft:'3px solid var(--accent)' }}>
                  Site Settings
                </div>
                <button onClick={saveSettings} className="btn-accent" style={{ display:'inline-flex', alignItems:'center', gap:8, padding:'9px 20px' }} disabled={settingsSaving}>
                  <i className={`bi ${settingsSaving?'bi-arrow-clockwise':'bi-check2-all'}`} style={{animation:settingsSaving?'spin 1s linear infinite':''}} />
                  {settingsSaving?'Saving…':'Save All Changes'}
                </button>
              </div>

              {/* Announcement Banner */}
              <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden', marginBottom:20 }}>
                <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                  Announcement Banner
                  <label style={{ display:'flex', alignItems:'center', gap:8, cursor:'pointer', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.85rem', fontWeight:600, textTransform:'none', letterSpacing:0 }}>
                    <input type="checkbox" checked={!!settings.bannerEnabled} onChange={e=>setSettings(s=>({...s,bannerEnabled:e.target.checked}))} style={{ accentColor:'var(--accent)', width:15, height:15 }} />
                    {settings.bannerEnabled?'Visible on site':'Hidden'}
                  </label>
                </div>
                <div style={{ padding:20, display:'grid', gridTemplateColumns:'1fr auto', gap:14, alignItems:'start' }}>
                  <div>
                    <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:7 }}>Banner Message</label>
                    <input style={{ width:'100%', background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.95rem', padding:'10px 13px', outline:'none' }}
                      value={settings.bannerText||''} onChange={e=>setSettings(s=>({...s,bannerText:e.target.value}))}
                      onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                  </div>
                  <div>
                    <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:7 }}>Color</label>
                    <input type="color" value={settings.bannerColor||'#d57454'} onChange={e=>setSettings(s=>({...s,bannerColor:e.target.value}))} style={{ width:44, height:40, border:'1px solid var(--border)', borderRadius:6, cursor:'pointer', background:'var(--bg)', padding:4 }} />
                  </div>
                </div>
                {settings.bannerEnabled && (
                  <div style={{ margin:'0 20px 20px', padding:'10px 16px', borderRadius:6, background:settings.bannerColor||'var(--accent)', color:'#fff', fontSize:'0.88rem', fontWeight:600, textAlign:'center' }}>
                    Preview: {settings.bannerText}
                  </div>
                )}
              </div>

              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, marginBottom:20 }}>
                {/* Header / Brand */}
                <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden' }}>
                  <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5 }}>
                    Header & Brand
                  </div>
                  <div style={{ padding:20, display:'flex', flexDirection:'column', gap:14 }}>
                    {[
                      ['Store Name',    'storeName',    'e.g. GameStore'],
                      ['Tagline',       'storeTagline', 'e.g. Your gaming destination'],
                      ['Icon Class',    'storeIcon',    'e.g. bi-controller'],
                    ].map(([label2, key, ph]) => (
                      <div key={key}>
                        <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:7 }}>{label2}</label>
                        <input style={{ width:'100%', background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.95rem', padding:'10px 13px', outline:'none' }}
                          value={settings[key]||''} placeholder={ph} onChange={e=>setSettings(s=>({...s,[key]:e.target.value}))}
                          onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                      </div>
                    ))}
                    <div>
                      <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:7 }}>Accent Color</label>
                      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                        <input type="color" value={settings.accentColor||'#d57454'} onChange={e=>setSettings(s=>({...s,accentColor:e.target.value}))} style={{ width:44, height:40, border:'1px solid var(--border)', borderRadius:6, cursor:'pointer', background:'var(--bg)', padding:4 }} />
                        <span style={{ fontSize:'0.85rem', color:'var(--dim)', fontFamily:'monospace' }}>{settings.accentColor}</span>
                      </div>
                    </div>
                    {/* Live preview */}
                    <div style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, padding:'12px 16px', display:'flex', alignItems:'center', gap:10 }}>
                      <i className={`bi ${settings.storeIcon||'bi-controller'}`} style={{ color:settings.accentColor||'var(--accent)', fontSize:'1.4rem' }} />
                      <div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:'1.1rem', fontWeight:900, color:settings.accentColor||'var(--accent)', letterSpacing:2 }}>{settings.storeName||'GameStore'}</div>
                        <div style={{ fontSize:'0.72rem', color:'var(--dim)' }}>{settings.storeTagline}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Business Info */}
                <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden' }}>
                  <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5 }}>
                    Business Information
                  </div>
                  <div style={{ padding:20, display:'flex', flexDirection:'column', gap:14 }}>
                    {[
                      ['Business Name',    'businessName',    'GameStore Pvt. Ltd.'],
                      ['Support Email',    'businessEmail',   'support@gamestore.in'],
                      ['Phone Number',     'businessPhone',   '+91 98765 43210'],
                      ['Address',          'businessAddress', 'Mumbai, Maharashtra'],
                      ['GST Number',       'businessGST',     'GST27AAAAA0000A1Z5'],
                      ['Support Hours',    'supportHours',    '24/7 · 365 days'],
                    ].map(([label2, key, ph]) => (
                      <div key={key}>
                        <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:7 }}>{label2}</label>
                        <input style={{ width:'100%', background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.95rem', padding:'10px 13px', outline:'none' }}
                          value={settings[key]||''} placeholder={ph} onChange={e=>setSettings(s=>({...s,[key]:e.target.value}))}
                          onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Footer Settings */}
              <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden', marginBottom:20 }}>
                <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5 }}>
                  Footer Content
                </div>
                <div style={{ padding:20, display:'grid', gridTemplateColumns:'1fr 1fr', gap:20 }}>
                  <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
                    {[
                      ['Copyright Text', 'footerText',    '© 2025 GameStore. All rights reserved.'],
                      ['Footer Subtext', 'footerSubtext', 'All prices in INR · Instant delivery'],
                    ].map(([label2, key, ph]) => (
                      <div key={key}>
                        <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:7 }}>{label2}</label>
                        <input style={{ width:'100%', background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.95rem', padding:'10px 13px', outline:'none' }}
                          value={settings[key]||''} placeholder={ph} onChange={e=>setSettings(s=>({...s,[key]:e.target.value}))}
                          onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                      </div>
                    ))}

                    {/* Social Links */}
                    <div>
                      <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:10 }}>Social Links</label>
                      {(settings.socialLinks||[]).map((link, i) => (
                        <div key={i} style={{ display:'grid', gridTemplateColumns:'auto 1fr 1fr auto', gap:8, marginBottom:8, alignItems:'center' }}>
                          <i className={`bi ${link.icon}`} style={{ color:'var(--accent)', fontSize:'1.1rem', width:24, textAlign:'center' }} />
                          <input style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:5, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.85rem', padding:'7px 10px', outline:'none' }}
                            value={link.label} placeholder="Label" onChange={e=>{const sl=[...(settings.socialLinks||[])];sl[i]={...sl[i],label:e.target.value};setSettings(s=>({...s,socialLinks:sl}));}}
                            onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                          <input style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:5, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.85rem', padding:'7px 10px', outline:'none' }}
                            value={link.url} placeholder="URL" onChange={e=>{const sl=[...(settings.socialLinks||[])];sl[i]={...sl[i],url:e.target.value};setSettings(s=>({...s,socialLinks:sl}));}}
                            onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                          <button onClick={()=>{const sl=(settings.socialLinks||[]).filter((_,j)=>j!==i);setSettings(s=>({...s,socialLinks:sl}));}} style={{ background:'none', border:'1px solid rgba(224,82,82,.3)', borderRadius:5, color:'var(--danger)', cursor:'pointer', padding:'6px 10px', fontSize:'0.8rem' }}>
                            <i className="bi bi-trash" />
                          </button>
                        </div>
                      ))}
                      <button onClick={()=>setSettings(s=>({...s,socialLinks:[...(s.socialLinks||[]),{icon:'bi-link-45deg',label:'New Link',url:'#'}]}))}
                        style={{ marginTop:4, background:'none', border:'1px dashed var(--border)', borderRadius:5, color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.8rem', textTransform:'uppercase', padding:'7px 16px', cursor:'pointer', width:'100%' }}>
                        + Add Social Link
                      </button>
                    </div>
                  </div>

                  {/* Footer links */}
                  <div>
                    <label style={{ display:'block', fontSize:'0.68rem', textTransform:'uppercase', letterSpacing:1.5, color:'var(--dim)', marginBottom:10 }}>Footer Links</label>
                    {(settings.footerLinks||[]).map((link, i) => (
                      <div key={i} style={{ display:'grid', gridTemplateColumns:'1fr 1fr auto', gap:8, marginBottom:8, alignItems:'center' }}>
                        <input style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:5, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.85rem', padding:'7px 10px', outline:'none' }}
                          value={link.label} placeholder="Label" onChange={e=>{const fl=[...(settings.footerLinks||[])];fl[i]={...fl[i],label:e.target.value};setSettings(s=>({...s,footerLinks:fl}));}}
                          onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                        <input style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:5, color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.85rem', padding:'7px 10px', outline:'none' }}
                          value={link.url} placeholder="URL or #" onChange={e=>{const fl=[...(settings.footerLinks||[])];fl[i]={...fl[i],url:e.target.value};setSettings(s=>({...s,footerLinks:fl}));}}
                          onFocus={e=>e.target.style.borderColor='var(--accent)'} onBlur={e=>e.target.style.borderColor='var(--border)'} />
                        <button onClick={()=>{const fl=(settings.footerLinks||[]).filter((_,j)=>j!==i);setSettings(s=>({...s,footerLinks:fl}));}} style={{ background:'none', border:'1px solid rgba(224,82,82,.3)', borderRadius:5, color:'var(--danger)', cursor:'pointer', padding:'6px 10px', fontSize:'0.8rem' }}>
                          <i className="bi bi-trash" />
                        </button>
                      </div>
                    ))}
                    <button onClick={()=>setSettings(s=>({...s,footerLinks:[...(s.footerLinks||[]),{label:'New Link',url:'#'}]}))}
                      style={{ marginTop:4, background:'none', border:'1px dashed var(--border)', borderRadius:5, color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.8rem', textTransform:'uppercase', padding:'7px 16px', cursor:'pointer', width:'100%' }}>
                      + Add Footer Link
                    </button>

                    {/* Footer preview */}
                    <div style={{ marginTop:20, background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, padding:'16px 20px' }}>
                      <div style={{ fontSize:'0.65rem', textTransform:'uppercase', letterSpacing:1, color:'var(--dim)', marginBottom:10 }}>Footer Preview</div>
                      <div style={{ textAlign:'center', color:'var(--dim)', fontSize:'0.8rem', lineHeight:1.8 }}>
                        {(settings.socialLinks||[]).map((l,i)=>(
                          <i key={i} className={`bi ${l.icon}`} style={{ margin:'0 8px', fontSize:'1.1rem', color:settings.accentColor||'var(--accent)' }} />
                        ))}
                        <br/>
                        {settings.footerText}<br/>
                        <span style={{ fontSize:'0.72rem', opacity:.7 }}>{settings.footerSubtext}</span><br/>
                        {(settings.footerLinks||[]).map((l,i)=>(
                          <span key={i} style={{ margin:'0 8px', fontSize:'0.72rem', opacity:.6 }}>{l.label}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Nav Links editor */}
              <div style={{ background:'var(--card)', border:'1px solid var(--border)', borderRadius:8, overflow:'hidden', marginBottom:20 }}>
                <div style={{ padding:'14px 20px', borderBottom:'1px solid var(--border)', fontFamily:"'Barlow Condensed',sans-serif", fontWeight:700, fontSize:'1rem', textTransform:'uppercase', letterSpacing:1.5 }}>
                  Header Navigation Links
                </div>
                <div style={{ padding:20 }}>
                  <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:10, marginBottom:12 }}>
                    {(settings.navLinks||[]).map((link, i) => (
                      <div key={i} style={{ background:'var(--bg)', border:'1px solid var(--border)', borderRadius:6, padding:'10px 14px', display:'flex', alignItems:'center', gap:8 }}>
                        <div style={{ flex:1, display:'flex', flexDirection:'column', gap:6 }}>
                          <input style={{ background:'transparent', border:'none', borderBottom:'1px solid var(--border)', color:'var(--text)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.88rem', fontWeight:700, padding:'3px 0', outline:'none', width:'100%' }}
                            value={link.label} placeholder="Label" onChange={e=>{const nl=[...(settings.navLinks||[])];nl[i]={...nl[i],label:e.target.value};setSettings(s=>({...s,navLinks:nl}));}} />
                          <input style={{ background:'transparent', border:'none', borderBottom:'1px solid var(--border)', color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontSize:'0.78rem', padding:'3px 0', outline:'none', width:'100%' }}
                            value={link.category} placeholder="category slug" onChange={e=>{const nl=[...(settings.navLinks||[])];nl[i]={...nl[i],category:e.target.value};setSettings(s=>({...s,navLinks:nl}));}} />
                        </div>
                        <button onClick={()=>{const nl=(settings.navLinks||[]).filter((_,j)=>j!==i);setSettings(s=>({...s,navLinks:nl}));}} style={{ background:'none', border:'none', color:'var(--danger)', cursor:'pointer', fontSize:'0.9rem', flexShrink:0 }}>
                          <i className="bi bi-x-lg" />
                        </button>
                      </div>
                    ))}
                  </div>
                  <button onClick={()=>setSettings(s=>({...s,navLinks:[...(s.navLinks||[]),{label:'New Link',category:'all'}]}))}
                    style={{ background:'none', border:'1px dashed var(--border)', borderRadius:5, color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.8rem', textTransform:'uppercase', padding:'8px 18px', cursor:'pointer' }}>
                    + Add Nav Link
                  </button>
                </div>
              </div>

              <div style={{ display:'flex', justifyContent:'flex-end', gap:12 }}>
                <button onClick={loadSettings} style={{ padding:'10px 20px', background:'none', border:'1px solid var(--border)', borderRadius:6, color:'var(--dim)', fontFamily:"'Rajdhani',sans-serif", fontWeight:700, fontSize:'0.9rem', textTransform:'uppercase', cursor:'pointer' }}>
                  Reset
                </button>
                <button onClick={saveSettings} className="btn-accent" style={{ padding:'10px 24px', display:'inline-flex', alignItems:'center', gap:8 }} disabled={settingsSaving}>
                  <i className={`bi ${settingsSaving?'bi-arrow-clockwise':'bi-check2-all'}`} style={{animation:settingsSaving?'spin 1s linear infinite':''}} />
                  {settingsSaving?'Saving…':'Save All Changes'}
                </button>
              </div>
            </div>
          )}

          {/* ── HERO SLIDER ── */}
          {activePage === 'slider' && (
            <div>
              <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.1rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, paddingLeft: 12, borderLeft: '3px solid var(--accent)', marginBottom: 20 }}>
                Hero Slider Manager
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
                {/* Current slider */}
                <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '1rem', textTransform: 'uppercase', letterSpacing: 1.5, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    Current Slides
                    <span style={{ background: 'rgba(213,116,84,.12)', border: '1px solid rgba(213,116,84,.3)', color: 'var(--accent)', fontSize: '0.65rem', fontWeight: 700, padding: '2px 10px', borderRadius: 10 }}>{sliderGames.length} / 5</span>
                  </div>
                  {sliderGames.length === 0
                    ? <div style={{ padding: '30px 20px', textAlign: 'center', color: 'var(--dim)', fontSize: '0.85rem' }}>No slides added yet.</div>
                    : sliderGames.map((g, i) => (
                        <div key={g.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 18px', borderBottom: '1px solid var(--border)', transition: 'background 0.2s' }}
                          onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,.02)'}
                          onMouseLeave={e => e.currentTarget.style.background = ''}>
                          <i className="bi bi-grip-vertical" style={{ color: 'var(--dim)', cursor: 'grab' }} />
                          <img src={g.img} alt={g.title} style={{ width: 72, height: 44, objectFit: 'cover', borderRadius: 4, flexShrink: 0 }} onError={e => { e.target.src = `https://placehold.co/72x44/12151a/d57454?text=G`; }} />
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ fontWeight: 700, fontSize: '0.9rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{g.title}</div>
                            <div style={{ fontSize: '0.72rem', color: 'var(--dim)', textTransform: 'uppercase', letterSpacing: 0.5 }}>{g.genre}</div>
                          </div>
                          <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'var(--accent)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700, flexShrink: 0 }}>{i + 1}</div>
                          <button onClick={() => toggleSlider(g)} style={{ background: 'none', border: 'none', color: 'var(--dim)', cursor: 'pointer', fontSize: '0.95rem', padding: 4, transition: 'color 0.2s' }}
                            onMouseEnter={e => e.target.style.color = 'var(--danger)'}
                            onMouseLeave={e => e.target.style.color = 'var(--dim)'}>
                            <i className="bi bi-x-lg" />
                          </button>
                        </div>
                      ))}
                  <div style={{ padding: '12px 18px', fontSize: '0.75rem', color: 'var(--dim)', textAlign: 'center', borderTop: sliderGames.length ? '1px solid var(--border)' : 'none', background: 'rgba(232,184,75,.04)' }}>
                    <i className="bi bi-info-circle" style={{ marginRight: 6 }} />Recommended: 3–5 slides for best experience
                  </div>
                </div>

                {/* Available games to add */}
                <div style={{ background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--border)', fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '1rem', textTransform: 'uppercase', letterSpacing: 1.5 }}>
                    Available Games
                  </div>
                  <div style={{ maxHeight: 420, overflowY: 'auto' }}>
                    {nonSliderGames.map(g => (
                      <div key={g.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 18px', borderBottom: '1px solid var(--border)', transition: 'background 0.2s' }}
                        onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,.02)'}
                        onMouseLeave={e => e.currentTarget.style.background = ''}>
                        <img src={g.img} alt={g.title} style={{ width: 52, height: 36, objectFit: 'cover', borderRadius: 4 }} onError={e => { e.target.src = `https://placehold.co/52x36/12151a/d57454?text=G`; }} />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 700, fontSize: '0.85rem', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{g.title}</div>
                          <div style={{ fontSize: '0.7rem', color: 'var(--dim)' }}>{g.genre}</div>
                        </div>
                        <button disabled={sliderGames.length >= 5} onClick={() => toggleSlider(g)}
                          style={{ marginLeft: 'auto', background: sliderGames.length >= 5 ? 'transparent' : 'rgba(213,116,84,.12)', border: '1px solid rgba(213,116,84,.3)', borderRadius: 5, color: sliderGames.length >= 5 ? 'var(--dim)' : 'var(--accent)', fontSize: '0.75rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, padding: '4px 12px', cursor: sliderGames.length >= 5 ? 'not-allowed' : 'pointer', transition: 'all 0.2s', flexShrink: 0, opacity: sliderGames.length >= 5 ? 0.4 : 1 }}>
                          + Add
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
