import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import GAME_DETAILS from '../data/gameDetails';

const s = {
  nav: { background: '#0d0f12', borderBottom: '1px solid var(--border)', padding: '0 24px', height: 56, display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 200 },
  brand: { fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.6rem', fontWeight: 900, color: 'var(--accent)', letterSpacing: 2, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8 },
  backLink: { color: 'var(--dim)', fontWeight: 600, fontSize: '0.85rem', textTransform: 'uppercase', letterSpacing: 1, display: 'flex', alignItems: 'center', gap: 6, transition: 'color 0.2s' },
  card: { background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 6, overflow: 'hidden' },
  img: { width: '100%', height: 320, objectFit: 'cover', display: 'block' },
  title: { fontFamily: "'Barlow Condensed', sans-serif", fontSize: '2.8rem', fontWeight: 800, textTransform: 'uppercase', color: 'var(--accent)', lineHeight: 1, marginBottom: 12 },
  tag: { fontSize: '0.78rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, padding: '3px 12px', borderRadius: 20, border: '1px solid rgba(255,255,255,0.15)', background: 'rgba(255,255,255,0.05)', color: 'var(--text)', display: 'inline-block' },
  specLabel: { color: 'var(--accent)', fontWeight: 700, fontSize: '0.8rem', textTransform: 'uppercase', letterSpacing: 1 },
  buyArea: { background: '#0d0f12', borderTop: '1px solid var(--border)', padding: '28px 24px', textAlign: 'center' },
  price: (free) => ({ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '3rem', fontWeight: 800, color: free ? '#27ae60' : 'var(--accent)', marginBottom: 16 }),
  buyBtn: { background: 'var(--accent)', color: '#fff', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.2rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, border: 'none', borderRadius: 4, padding: '14px 48px', cursor: 'pointer', transition: 'background 0.2s, transform 0.1s' },
  dlBtn: { background: '#27ae60', color: '#fff', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.2rem', fontWeight: 800, textTransform: 'uppercase', letterSpacing: 2, border: 'none', borderRadius: 4, padding: '14px 48px', cursor: 'pointer', transition: 'background 0.2s, transform 0.1s' },
};

function triggerDownload(title) {
  const lines = [
    '╔══════════════════════════════════════════╗',
    '║        GameStore – Official Installer     ║',
    '╚══════════════════════════════════════════╝',
    '', `  Game   : ${title}`, '  Version: 1.0.0', `  Date   : ${new Date().toLocaleDateString('en-IN')}`,
    '', '  This is a FREE game. No payment required.',
    '  Download and enjoy!',
    '', '══════════════════════════════════════════════',
    '  GameStore © 2025 · All Rights Reserved',
    '══════════════════════════════════════════════',
  ].join('\r\n');
  const blob = new Blob([lines], { type: 'application/octet-stream' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = title.replace(/[^a-zA-Z0-9]/g, '_') + '_Free_Setup.exe';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export default function GameDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [game, setGame] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/games/${id}`)
      .then(r => r.ok ? r.json() : null)
      .then(data => { setGame(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id]);

  const detail = GAME_DETAILS[id];
  const isFree = game?.price === 0;

  return (
    <>
      <nav style={s.nav}>
        <Link to="/" style={s.brand}><i className="bi bi-controller" /> GameStore</Link>
        <Link to="/" style={s.backLink}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--accent)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--dim)'}>
          <i className="bi bi-arrow-left" /> Back to Store
        </Link>
      </nav>

      <div style={{ maxWidth: 960, margin: '32px auto', padding: '0 20px' }}>
        {loading && (
          <div style={{ textAlign: 'center', padding: 60, color: 'var(--dim)' }}>
            <i className="bi bi-controller" style={{ fontSize: '2.5rem', color: 'var(--accent)', display: 'block', marginBottom: 12 }} />
            Loading…
          </div>
        )}

        {!loading && !game && (
          <div style={{ textAlign: 'center', padding: 60 }}>
            <div style={{ fontSize: '4rem', marginBottom: 16 }}>🎮</div>
            <h2 style={{ fontFamily: "'Barlow Condensed', sans-serif", color: 'var(--accent)', textTransform: 'uppercase' }}>Game Not Found</h2>
            <p style={{ color: 'var(--dim)', marginBottom: 24 }}>We couldn't find that game in our store.</p>
            <button className="btn-accent" onClick={() => navigate('/')}>← Back to Store</button>
          </div>
        )}

        {!loading && game && (
          <div style={s.card}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: 0 }}>
              {/* Left – image */}
              <img src={game.img} alt={game.title} style={s.img}
                onError={e => { e.target.src = `https://placehold.co/500x320/12151a/d57454?text=${encodeURIComponent(game.title)}`; }} />

              {/* Right – info */}
              <div style={{ padding: 28, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <div>
                  <h1 style={s.title}>{game.title}</h1>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 16 }}>
                    {(detail?.tags || [game.genre]).map(t => (
                      <span key={t} style={s.tag}>{t}</span>
                    ))}
                  </div>
                  <p style={{ color: 'var(--dim)', lineHeight: 1.7, marginBottom: 20, fontSize: '0.95rem' }}>
                    {detail?.desc || `A great ${game.genre} game available on ${game.platform || 'PC'}.`}
                  </p>
                  {detail?.specs && (
                    <table style={{ width: '100%' }}>
                      <tbody>
                        {detail.specs.map(([label, val]) => (
                          <tr key={label} style={{ borderBottom: '1px solid var(--border)' }}>
                            <td style={{ ...s.specLabel, padding: '10px 0', width: '35%' }}>{label}</td>
                            <td style={{ padding: '10px 0', fontSize: '0.92rem', color: 'var(--text)' }}>{val}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>
            </div>

            {/* Buy area */}
            <div style={s.buyArea}>
              <div style={s.price(isFree)}>{isFree ? 'FREE' : '₹' + game.price.toLocaleString('en-IN')}</div>
              {isFree
                ? <button style={s.dlBtn} onClick={() => triggerDownload(game.title)}
                    onMouseEnter={e => { e.target.style.background = '#1e8449'; e.target.style.transform = 'translateY(-2px)'; }}
                    onMouseLeave={e => { e.target.style.background = '#27ae60'; e.target.style.transform = ''; }}>
                    ⬇ Free Download
                  </button>
                : <button style={s.buyBtn} onClick={() => navigate(`/payment?game=${encodeURIComponent(game.title)}&price=${game.price}`)}
                    onMouseEnter={e => { e.target.style.background = '#bf5f40'; e.target.style.transform = 'translateY(-2px)'; }}
                    onMouseLeave={e => { e.target.style.background = 'var(--accent)'; e.target.style.transform = ''; }}>
                    🛒 Buy Now & Download
                  </button>}
              <p style={{ color: 'var(--dim)', fontSize: '0.82rem', marginTop: 12, marginBottom: 0 }}>
                🔒 Secure payment · Instant digital delivery
              </p>
            </div>
          </div>
        )}
      </div>

      <footer style={{ textAlign: 'center', padding: '30px 20px', color: 'var(--dim)', fontSize: '0.8rem', borderTop: '1px solid var(--border)', marginTop: 40 }}>
        © 2025 GameStore. All rights reserved. · All prices in INR.
      </footer>
    </>
  );
}
