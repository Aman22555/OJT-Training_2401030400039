import React, { createContext, useContext, useState, useCallback } from 'react';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]   = useState(() => {
    try { return JSON.parse(sessionStorage.getItem('gs_user')) || null; } catch { return null; }
  });
  const [isAdmin, setIsAdmin] = useState(() => sessionStorage.getItem('gs_admin') === 'true');

  const login = useCallback((userData, admin = false) => {
    setUser(userData);
    setIsAdmin(admin);
    sessionStorage.setItem('gs_user', JSON.stringify(userData));
    if (admin) sessionStorage.setItem('gs_admin', 'true');
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsAdmin(false);
    sessionStorage.clear();
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAdmin, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() { return useContext(AuthContext); }
