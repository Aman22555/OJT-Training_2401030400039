import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

const s = {
  wrap: { position: 'relative', height: 420, overflow: 'hidden', borderRadius: 8, border: '1px solid var(--border)', cursor: 'pointer' },
  img: { width: '100%', height: '100%', objectFit: 'cover', filter: 'brightness(0.5)', transition: 'opacity 0.5s' },
  caption: { position: 'absolute', bottom: 40, left: '5%', textAlign: 'left' },
  genre: { fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: 3, color: 'rgba(232,224,214,.7)', marginBottom: 10 },
  title: { fontFamily: "'Barlow Condensed', sans-serif", fontSize: '2.8rem', fontWeight: 900, color: 'var(--text)', textTransform: 'uppercase', lineHeight: 1, marginBottom: 10, textShadow: '0 2px 8px rgba(0,0,0,.5)' },
  priceTag: (free) => ({ display: 'inline-block', background: free ? '#27ae60' : 'var(--accent)', color: '#fff', padding: '5px 16px', fontWeight: 700, fontSize: '0.95rem', borderRadius: 3 }),
  btn: { marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 8, padding: '10px 22px', background: 'var(--accent)', color: '#fff', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1.5, border: 'none', borderRadius: 4, cursor: 'pointer' },
  arrow: { position: 'absolute', top: '50%', transform: 'translateY(-50%)', background: 'rgba(0,0,0,.5)', border: 'none', color: '#fff', fontSize: '1.2rem', padding: '12px 16px', cursor: 'pointer', zIndex: 10, borderRadius: 4 },
  dots: { position: 'absolute', bottom: 14, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 8 },
  dot: (active) => ({ width: active ? 24 : 8, height: 8, borderRadius: 4, background: active ? 'var(--accent)' : 'rgba(255,255,255,.3)', transition: 'all 0.3s', border: 'none', cursor: 'pointer', padding: 0 }),
};

export default function Carousel({ games }) {
  const [idx, setIdx] = useState(0);
  const navigate = useNavigate();
  const slides = games.filter(g => g.inSlider).length ? games.filter(g => g.inSlider) : games.filter(g => g.featured).slice(0, 3);

  const next = useCallback(() => setIdx(i => (i + 1) % slides.length), [slides.length]);
  const prev = () => setIdx(i => (i - 1 + slides.length) % slides.length);

  useEffect(() => {
    const t = setInterval(next, 5000);
    return () => clearInterval(t);
  }, [next]);

  if (!slides.length) return null;
  const g = slides[idx];

  return (
    <div style={s.wrap} onClick={() => navigate(`/game/${g.id}`)}>
      <img src={g.img} alt={g.title} style={s.img} onError={e => { e.target.src = `https://placehold.co/1200x420/12151a/d57454?text=${encodeURIComponent(g.title)}`; }} />

      <div style={s.caption}>
        <div style={s.genre}>{g.genre}</div>
        <div style={s.title}>{g.title}</div>
        <span style={s.priceTag(g.price === 0)}>{g.price === 0 ? 'FREE' : '₹' + g.price.toLocaleString('en-IN')}</span>
        <br />
        <button style={s.btn} onClick={e => { e.stopPropagation(); navigate(g.price === 0 ? `/game/${g.id}` : `/payment?game=${encodeURIComponent(g.title)}&price=${g.price}`); }}>
          {g.price === 0
            ? <><i className="bi bi-download" /> Download Free</>
            : <><i className="bi bi-cart-fill" /> Buy Now</>}
        </button>
      </div>

      <button style={{ ...s.arrow, left: 12 }} onClick={e => { e.stopPropagation(); prev(); }}>
        <i className="bi bi-chevron-left" />
      </button>
      <button style={{ ...s.arrow, right: 12 }} onClick={e => { e.stopPropagation(); next(); }}>
        <i className="bi bi-chevron-right" />
      </button>

      <div style={s.dots}>
        {slides.map((_, i) => (
          <button key={i} style={s.dot(i === idx)} onClick={e => { e.stopPropagation(); setIdx(i); }} />
        ))}
      </div>
    </div>
  );
}
