import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const CATEGORIES = [
  { id: 'all',          label: 'All Games',       icon: 'bi-grid-3x3-gap' },
  { id: 'battle-royale',label: 'Battle Royale',   icon: 'bi-crosshair2' },
  { id: 'fps-shooter',  label: 'FPS / Shooter',   icon: 'bi-bullseye' },
  { id: 'rpg',          label: 'RPG',             icon: 'bi-map' },
  { id: 'action',       label: 'Action',          icon: 'bi-lightning-fill' },
  { id: 'racing',       label: 'Racing',          icon: 'bi-speedometer2' },
  { id: 'sports',       label: 'Sports',          icon: 'bi-trophy-fill' },
  { id: 'puzzle',       label: 'Puzzle',          icon: 'bi-puzzle' },
  { id: 'simulation',   label: 'Simulation',      icon: 'bi-globe2' },
  { id: 'free',         label: 'Free',            icon: 'bi-gift-fill', green: true },
];

const styles = {
  nav: { background: '#0d0f12', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 200, padding: '0 24px' },
  inner: { display: 'flex', alignItems: 'center', height: 56, gap: 24, maxWidth: 1400, margin: '0 auto' },
  brand: { fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.6rem', fontWeight: 900, color: 'var(--accent)', letterSpacing: 2, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 },
  navLinks: { display: 'flex', gap: 4, alignItems: 'center', flex: 1, overflow: 'hidden' },
  navLink: { color: 'var(--dim)', fontWeight: 600, fontSize: '0.82rem', textTransform: 'uppercase', letterSpacing: 1, padding: '6px 10px', borderRadius: 4, transition: 'color 0.2s', whiteSpace: 'nowrap', cursor: 'pointer' },
  searchWrap: { position: 'relative', width: 240, flexShrink: 0 },
  searchInput: { width: '100%', background: '#0a0d12', border: '1px solid var(--border)', borderRadius: 5, color: 'var(--text)', fontFamily: "'Rajdhani', sans-serif", fontSize: '0.9rem', padding: '8px 36px 8px 12px', outline: 'none' },
  searchBtn: { position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: 'var(--dim)', cursor: 'pointer', fontSize: '1rem' },
  dropdown: { position: 'absolute', top: 'calc(100% + 6px)', left: 0, right: 0, background: '#12151a', border: '1px solid var(--accent)', borderRadius: 6, listStyle: 'none', padding: '4px 0', zIndex: 9999, boxShadow: '0 8px 24px rgba(0,0,0,.6)', maxHeight: 320, overflowY: 'auto' },
  dropItem: { padding: '8px 12px', cursor: 'pointer', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 10, transition: 'background 0.15s' },
  actions: { display: 'flex', gap: 8, flexShrink: 0, alignItems: 'center' },
  loginBtn: { background: 'var(--accent)', color: '#fff', border: 'none', borderRadius: 4, fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '0.9rem', textTransform: 'uppercase', letterSpacing: 1, padding: '7px 16px', cursor: 'pointer' },
  adminBtn: { display: 'flex', alignItems: 'center', gap: 5, padding: '6px 12px', borderRadius: 4, background: 'rgba(213,116,84,.1)', border: '1px solid rgba(213,116,84,.3)', color: 'var(--accent)', fontWeight: 700, fontSize: '0.8rem', textTransform: 'uppercase', cursor: 'pointer' },
  userChip: { display: 'flex', alignItems: 'center', gap: 6, color: 'var(--dim)', fontSize: '0.82rem', fontWeight: 600 },
  catBar: { background: '#0b0d10', borderBottom: '1px solid var(--border)', overflowX: 'auto', whiteSpace: 'nowrap', padding: '0 16px', scrollbarWidth: 'none' },
  catTab: (active, green) => ({ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '10px 16px', fontFamily: "'Barlow Condensed', sans-serif", fontSize: '0.83rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1.5, color: active ? 'var(--accent)' : green ? '#3ec97a' : 'var(--dim)', borderBottom: `3px solid ${active ? 'var(--accent)' : 'transparent'}`, cursor: 'pointer', transition: 'all 0.2s', whiteSpace: 'nowrap', userSelect: 'none' }),
};

export default function Navbar({ activeCategory, onCategoryChange }) {
  const { user, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const [searchVal, setSearchVal] = useState('');
  const [dropItems, setDropItems] = useState([]);
  const [showDrop, setShowDrop] = useState(false);
  const [allGames, setAllGames] = useState([]);
  const inputRef = useRef();

  useEffect(() => {
    fetch('/api/games').then(r => r.json()).then(setAllGames).catch(() => {});
  }, []);

  function handleSearch(val) {
    setSearchVal(val);
    if (!val.trim()) { setShowDrop(false); return; }
    const q = val.toLowerCase();
    const matches = allGames.filter(g => g.title.toLowerCase().includes(q) || g.genre.toLowerCase().includes(q)).slice(0, 8);
    setDropItems(matches);
    setShowDrop(true);
  }

  function pickGame(g) {
    setSearchVal(g.title);
    setShowDrop(false);
    navigate(`/game/${g.id}`);
  }

  function runSearch() {
    setShowDrop(false);
    if (onCategoryChange) onCategoryChange('all', searchVal);
    navigate(`/?search=${encodeURIComponent(searchVal)}`);
  }

  return (
    <>
      <nav style={styles.nav}>
        <div style={styles.inner}>
          <Link to="/" style={styles.brand}>
            <i className="bi bi-controller" /> GameStore
          </Link>

          <div style={styles.navLinks}>
            {CATEGORIES.slice(1, 7).map(c => (
              <span key={c.id} style={{ ...styles.navLink, color: activeCategory === c.id ? 'var(--accent)' : c.green ? '#3ec97a' : 'var(--dim)' }}
                onClick={() => { onCategoryChange?.(c.id); navigate('/'); }}>
                {c.label}
              </span>
            ))}
          </div>

          <div style={styles.searchWrap}>
            <input
              ref={inputRef}
              style={styles.searchInput}
              placeholder="Search games…"
              value={searchVal}
              onChange={e => handleSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && runSearch()}
              onBlur={() => setTimeout(() => setShowDrop(false), 150)}
            />
            <button style={styles.searchBtn} onClick={runSearch}><i className="bi bi-search" /></button>
            {showDrop && dropItems.length > 0 && (
              <ul style={styles.dropdown}>
                {dropItems.map(g => (
                  <li key={g.id} style={styles.dropItem}
                    onMouseDown={() => pickGame(g)}
                    onMouseEnter={e => e.currentTarget.style.background = '#1a1f27'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <img src={g.img} style={{ width: 48, height: 36, objectFit: 'cover', borderRadius: 4 }} alt={g.title} onError={e => { e.target.src = `https://placehold.co/48x36/12151a/d57454?text=${encodeURIComponent(g.title[0])}`; }} />
                    <div>
                      <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: '0.95rem', color: 'var(--text)', textTransform: 'uppercase' }}>{g.title}</div>
                      <div style={{ fontSize: '0.7rem', color: 'var(--dim)', textTransform: 'uppercase' }}>{g.genre}</div>
                    </div>
                    <div style={{ marginLeft: 'auto', fontWeight: 700, fontSize: '0.85rem', color: g.price === 0 ? '#27ae60' : 'var(--accent)' }}>
                      {g.price === 0 ? 'FREE' : '₹' + g.price.toLocaleString('en-IN')}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div style={styles.actions}>
            {user ? (
              <>
                <div style={styles.userChip}>
                  <i className="bi bi-person-circle" style={{ fontSize: '1.1rem', color: 'var(--accent)' }} />
                  {user.name}
                </div>
                <button style={styles.loginBtn} onClick={logout}>Logout</button>
              </>
            ) : (
              <button style={styles.loginBtn} onClick={() => navigate('/login')}>Login</button>
            )}
            {isAdmin && (
              <Link to="/admin" style={styles.adminBtn}>
                <i className="bi bi-shield-check" /> Admin
              </Link>
            )}
          </div>
        </div>
      </nav>

      <div style={styles.catBar}>
        {CATEGORIES.map(c => (
          <span key={c.id} style={styles.catTab(activeCategory === c.id, c.green)}
            onClick={() => { onCategoryChange?.(c.id); navigate('/'); }}>
            <i className={`bi ${c.icon}`} /> {c.label}
          </span>
        ))}
      </div>
    </>
  );
}
