import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function GameCard({ game }) {
  const navigate = useNavigate();
  const isFree = game.price === 0;

  return (
    <div onClick={() => navigate(`/game/${game.id}`)} style={{
      background: 'var(--card)', border: '1px solid var(--border)', borderRadius: 6,
      cursor: 'pointer', transition: 'transform 0.2s, border-color 0.2s', overflow: 'hidden',
    }}
      onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-4px)'; e.currentTarget.style.borderColor = 'var(--accent)'; }}
      onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.borderColor = 'var(--border)'; }}>
      <img src={game.img} alt={game.title}
        style={{ width: '100%', height: 160, objectFit: 'cover', display: 'block' }}
        onError={e => { e.target.src = `https://placehold.co/400x225/12151a/d57454?text=${encodeURIComponent(game.title)}`; }} />
      <div style={{ padding: '12px 14px' }}>
        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontSize: '1.05rem', fontWeight: 700, textTransform: 'uppercase', marginBottom: 4 }}>
          {game.title}
          {isFree && <span className="badge-free" style={{ marginLeft: 6 }}>Free</span>}
        </div>
        <div style={{ fontSize: '0.78rem', color: 'var(--dim)', marginBottom: 10 }}>{game.genre}</div>
        <span className={`badge-cat ${game.category}`}>{game.category.replace('-', ' ')}</span>
      </div>
      <div style={{ padding: '10px 14px', background: '#0d0f12', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontWeight: 700, color: isFree ? '#27ae60' : 'var(--accent)', fontSize: '1rem' }}>
          {isFree ? 'FREE' : '₹' + game.price.toLocaleString('en-IN')}
        </span>
        {isFree
          ? <button style={{ background: '#27ae60', color: '#fff', border: 'none', padding: '6px 14px', fontWeight: 700, fontSize: '0.82rem', textTransform: 'uppercase', borderRadius: 3, cursor: 'pointer' }}
              onClick={e => { e.stopPropagation(); }}>
              Download
            </button>
          : <button style={{ background: 'var(--accent)', color: '#fff', border: 'none', padding: '6px 14px', fontWeight: 700, fontSize: '0.82rem', textTransform: 'uppercase', borderRadius: 3, cursor: 'pointer' }}
              onClick={e => { e.stopPropagation(); navigate(`/payment?game=${encodeURIComponent(game.title)}&price=${game.price}`); }}>
              Buy
            </button>}
      </div>
    </div>
  );
}
