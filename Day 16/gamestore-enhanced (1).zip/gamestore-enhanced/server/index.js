const express = require('express');
const multer  = require('multer');
const fs      = require('fs');
const cors = require('cors');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json());

// ────────────────────────────────────────────────────────────
//  GOOGLE CLOUD FIRESTORE  (set GOOGLE_APPLICATION_CREDENTIALS
//  env-var to your service-account JSON, or use ADC)
// ────────────────────────────────────────────────────────────
let db = null;
let firestoreAvailable = false;

async function initFirestore() {
  try {
    const { Firestore } = require('@google-cloud/firestore');
    db = new Firestore({
      projectId: process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT,
    });
    // Quick probe
    await db.collection('_health').limit(1).get();
    firestoreAvailable = true;
    console.log('✅ Firestore connected');
  } catch (err) {
    console.warn('⚠️  Firestore unavailable – using in-memory store:', err.message);
    firestoreAvailable = false;
  }
}

// ── Firestore helpers ──────────────────────────────────────
async function fsGetUsers() {
  if (!firestoreAvailable) return inMemoryUsers;
  const snap = await db.collection('users').get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

async function fsSaveUser(userData) {
  if (!firestoreAvailable) {
    const existing = inMemoryUsers.findIndex(u => u.email === userData.email);
    if (existing >= 0) inMemoryUsers[existing] = { ...inMemoryUsers[existing], ...userData };
    else inMemoryUsers.push({ id: Date.now().toString(), ...userData, createdAt: new Date().toISOString() });
    return;
  }
  const ref = db.collection('users').doc(userData.uid || userData.email);
  await ref.set({ ...userData, updatedAt: Firestore.FieldValue ? Firestore.FieldValue.serverTimestamp() : new Date().toISOString() }, { merge: true });
}

async function fsSaveOrder(order) {
  if (!firestoreAvailable) { inMemoryOrders.push(order); return; }
  await db.collection('orders').doc(order.orderId).set(order);
}

async function fsGetOrders() {
  if (!firestoreAvailable) return inMemoryOrders;
  const snap = await db.collection('orders').orderBy('createdAt', 'desc').limit(100).get();
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

// ── In-memory fallback ─────────────────────────────────────
const inMemoryUsers  = [];
const inMemoryOrders = [];

// ── Games (still in-memory – replace with Firestore if you want) ──
const DEFAULT_GAMES = [
  { id:'bgmi',            title:'BGMI',                    genre:'Battle Royale',       category:'battle-royale', platform:'Mobile / PC', storage:'8GB',  price:6999.99, img:'https://i.ytimg.com/vi/-ErnVg5aDag/hq720.jpg',                                                                                                                featured:true,  inSlider:false },
  { id:'valorant',        title:'VALORANT',                genre:'Tactical Shooter',    category:'fps-shooter',   platform:'PC',          storage:'16GB', price:0,       img:'https://wallpapers.com/images/hd/4k-hd-valorant-1m8v8h6l10gnss81.jpg',                                                                                         featured:true,  inSlider:false },
  { id:'cs2',             title:'Counter-Strike 2',        genre:'FPS',                 category:'fps-shooter',   platform:'PC',          storage:'8GB',  price:0,       img:'https://wallpapercave.com/wp/wp12803694.png',                                                                                                                   featured:true,  inSlider:false },
  { id:'cyberpunk',       title:'Cyberpunk 2077',          genre:'RPG / Action',        category:'rpg',           platform:'PC',          storage:'70GB', price:2999,    img:'https://c4.wallpaperflare.com/wallpaper/943/63/773/cyberpunk-2077-cyberpunk-video-games-wallpaper-preview.jpg',                                              featured:true,  inSlider:true  },
  { id:'eldenring',       title:'Elden Ring',              genre:'Action RPG',          category:'rpg',           platform:'PC',          storage:'60GB', price:3599,    img:'https://4kwallpapers.com/images/wallpapers/elden-ring-7680x4320-20173.jpg',                                                                                      featured:true,  inSlider:true  },
  { id:'shadow-ninja',    title:'Shadow Ninja',            genre:'Action / Parkour',    category:'action',        platform:'PC',          storage:'4GB',  price:1499,    img:'https://images.wallpapersden.com/image/download/ninja-shadow-dark_bGZmbm6UmZqaraWkpJRmbmdlrWZlbWU.jpg',                                                        featured:false, inSlider:false },
  { id:'forza-horizon-6', title:'Forza Horizon 6',         genre:'Racing',              category:'racing',        platform:'PC',          storage:'100GB',price:3999,    img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSkRyEPyYuoSnmbQxKf4fCgeMlYhcSqnHvHYQ&s',                                                                  featured:true,  inSlider:false },
  { id:'god-of-war',      title:'God of War Ragnarök',     genre:'Action Adventure',    category:'action',        platform:'PC',          storage:'90GB', price:4999,    img:'https://cdn.wallpapersafari.com/15/57/uPNyez.jpg',                                                                                                              featured:true,  inSlider:true  },
  { id:'warframe',        title:'Warframe',                genre:'Action RPG · Co-op',  category:'action',        platform:'PC',          storage:'35GB', price:0,       img:'https://store-images.s-microsoft.com/image/apps.38512.68123456111492710.a7282e70-8b85-41b8-9cdf-3abcdb6b4b35.2f760735-01c5-4de8-88d3-54bf4584f043',            featured:true,  inSlider:false },
  { id:'genshin-impact',  title:'Genshin Impact',          genre:'Open World RPG',      category:'rpg',           platform:'PC',          storage:'80GB', price:0,       img:'https://wallpaperaccess.com/full/12211659.jpg',                                                                                                                 featured:true,  inSlider:false },
  { id:'fortnite',        title:'Fortnite',                genre:'Battle Royale',       category:'battle-royale', platform:'PC',          storage:'30GB', price:0,       img:'https://image.api.playstation.com/vulcan/ap/rnd/202603/2421/4244d47f72dffc0075a105f58e5d0bf0d3a4e6078f103a49.jpg',                                            featured:true,  inSlider:false },
  { id:'apex-legends',    title:'Apex Legends',            genre:'Battle Royale · FPS', category:'battle-royale', platform:'PC',          storage:'100GB',price:0,       img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSh3YdfwQ1MPGpDWclcS9c4n9XZtprMh-5hdw&s',                                                                  featured:true,  inSlider:false },
  { id:'gta-v',           title:'GTA V',                   genre:'Open World / Action', category:'action',        platform:'PC',          storage:'95GB', price:1999,    img:'https://upload.wikimedia.org/wikipedia/en/a/a5/Grand_Theft_Auto_V.png',                                                                                         featured:false, inSlider:false },
  { id:'witcher-3',       title:'The Witcher 3',           genre:'RPG / Open World',    category:'rpg',           platform:'PC',          storage:'50GB', price:2499,    img:'https://image.api.playstation.com/vulcan/ap/rnd/202211/0711/kh4MUIuMmHlktOHar3lROAqJ.png',                                                                    featured:false, inSlider:false },
  { id:'red-dead-2',      title:'Red Dead Redemption 2',  genre:'Action / Adventure',  category:'action',        platform:'PC',          storage:'150GB',price:3499,    img:'https://upload.wikimedia.org/wikipedia/en/4/44/Red_Dead_Redemption_II.jpg',                                                                                     featured:false, inSlider:false },
  { id:'dark-souls-3',    title:'Dark Souls III',          genre:'Action RPG',          category:'rpg',           platform:'PC',          storage:'25GB', price:1999,    img:'https://upload.wikimedia.org/wikipedia/en/8/8f/Dark_souls_3_logo.jpg',                                                                                          featured:false, inSlider:false },
  { id:'nfs-unbound',     title:'Need for Speed Unbound', genre:'Racing',              category:'racing',        platform:'PC',          storage:'50GB', price:2499,    img:'https://upload.wikimedia.org/wikipedia/en/b/be/Need_for_Speed_Unbound_cover.jpg',                                                                              featured:false, inSlider:false },
  { id:'rocket-league',   title:'Rocket League',          genre:'Sports / Racing',     category:'sports',        platform:'PC',          storage:'20GB', price:0,       img:'https://upload.wikimedia.org/wikipedia/en/a/a5/Rocket_League_coverart.jpg',                                                                                      featured:false, inSlider:false },
  { id:'fifa-25',         title:'EA Sports FC 25',        genre:'Sports / Football',   category:'sports',        platform:'PC',          storage:'50GB', price:3999,    img:'https://upload.wikimedia.org/wikipedia/en/8/82/EA_Sports_FC_25_Cover.jpg',                                                                                      featured:false, inSlider:false },
  { id:'nba-2k25',        title:'NBA 2K25',               genre:'Sports / Basketball', category:'sports',        platform:'PC',          storage:'150GB',price:3499,    img:'https://upload.wikimedia.org/wikipedia/en/thumb/4/4e/NBA_2K25_Cover.jpg/220px-NBA_2K25_Cover.jpg',                                                              featured:false, inSlider:false },
  { id:'portal-2',        title:'Portal 2',               genre:'Puzzle / Adventure',  category:'puzzle',        platform:'PC',          storage:'8GB',  price:999,     img:'https://upload.wikimedia.org/wikipedia/en/f/f9/Portal2cover.jpg',                                                                                               featured:false, inSlider:false },
  { id:'hollow-knight',   title:'Hollow Knight',          genre:'Metroidvania / Action',category:'puzzle',       platform:'PC',          storage:'9GB',  price:799,     img:'https://upload.wikimedia.org/wikipedia/commons/c/c5/Hollow_knight_silksong_logo.png',                                                                           featured:false, inSlider:false },
  { id:'minecraft',       title:'Minecraft',              genre:'Sandbox / Survival',  category:'simulation',    platform:'PC',          storage:'30GB', price:1499,    img:'https://upload.wikimedia.org/wikipedia/en/5/51/Minecraft_cover.png',                                                                                             featured:false, inSlider:false },
  { id:'stardew-valley',  title:'Stardew Valley',         genre:'Farming / RPG',       category:'simulation',    platform:'PC',          storage:'2GB',  price:799,     img:'https://upload.wikimedia.org/wikipedia/en/f/fd/Logo_of_Stardew_Valley.png',                                                                                     featured:false, inSlider:false },
  { id:'overwatch-2',     title:'Overwatch 2',            genre:'Hero Shooter',        category:'fps-shooter',   platform:'PC',          storage:'50GB', price:0,       img:'https://upload.wikimedia.org/wikipedia/en/4/4a/Overwatch2.jpg',                                                                                                 featured:false, inSlider:false },
];
let games = [...DEFAULT_GAMES];

// Admin credentials
const ADMIN_USER = 'Aman Vishwakarma';
const ADMIN_PASS = 'G057528Aman@';

// ── GAME ROUTES ───────────────────────────────────────────
app.get('/api/games', (req, res) => {
  const { category, search } = req.query;
  let result = games;
  if (category && category !== 'all') {
    if (category === 'free') result = result.filter(g => g.price === 0);
    else result = result.filter(g => g.category === category);
  }
  if (search) {
    const q = search.toLowerCase();
    result = result.filter(g =>
      g.title.toLowerCase().includes(q) || g.genre.toLowerCase().includes(q)
    );
  }
  res.json(result);
});
app.get('/api/games/:id', (req, res) => {
  const game = games.find(g => g.id === req.params.id);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  res.json(game);
});
app.post('/api/games', (req, res) => {
  const game = { ...req.body, id: req.body.id || Date.now().toString() };
  games.push(game);
  res.status(201).json(game);
});
app.put('/api/games/:id', (req, res) => {
  const idx = games.findIndex(g => g.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  games[idx] = { ...games[idx], ...req.body };
  res.json(games[idx]);
});
app.delete('/api/games/:id', (req, res) => {
  const idx = games.findIndex(g => g.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  games.splice(idx, 1);
  res.json({ success: true });
});

// ── AUTH ROUTES ───────────────────────────────────────────
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  if ((username === ADMIN_USER || username === 'admin') && (password === ADMIN_PASS || password === 'Admin@2025')) {
    return res.json({ success: true, role: 'admin', user: { name: username } });
  }
  const allUsers = await fsGetUsers();
  const user = allUsers.find(u => (u.email === username || u.username === username) && u.password === password);
  if (user) {
    return res.json({ success: true, role: 'user', user: { name: user.name, email: user.email, uid: user.id } });
  }
  res.status(401).json({ error: 'Invalid credentials' });
});

app.post('/api/auth/signup', async (req, res) => {
  const { name, email, password } = req.body;
  const allUsers = await fsGetUsers();
  if (allUsers.find(u => u.email === email)) {
    return res.status(400).json({ error: 'Email already registered' });
  }
  const userData = {
    name, email, username: email, password,
    provider: 'email',
    createdAt: new Date().toISOString(),
    totalSpent: 0,
    purchasedGames: [],
    status: 'active',
  };
  await fsSaveUser(userData);
  res.status(201).json({ success: true, user: { name, email } });
});

// Google OAuth – called from client after Firebase sign-in
app.post('/api/auth/google', async (req, res) => {
  const { uid, email, name, photoURL, provider } = req.body;
  if (!uid || !email) return res.status(400).json({ error: 'Missing uid or email' });

  const userData = {
    uid, email, name: name || email,
    photoURL: photoURL || '',
    username: email,
    provider: provider || 'google',
    createdAt: new Date().toISOString(),
    lastLogin: new Date().toISOString(),
    totalSpent: 0,
    purchasedGames: [],
    status: 'active',
  };
  await fsSaveUser(userData);
  res.json({ success: true, role: 'user', user: { name: userData.name, email, uid, photoURL: userData.photoURL } });
});

app.post('/api/auth/admin-login', (req, res) => {
  const { username, password } = req.body;
  if ((username === ADMIN_USER || username === 'admin') && (password === ADMIN_PASS || password === 'Admin@2025')) {
    return res.json({ success: true, user: { name: username } });
  }
  res.status(401).json({ error: 'Invalid admin credentials' });
});

// ── PAYMENT – Razorpay ────────────────────────────────────
let razorpay = null;
try {
  const Razorpay = require('razorpay');
  if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
    razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
    console.log('✅ Razorpay initialised');
  }
} catch (e) { /* package not installed – handled below */ }

// Create a Razorpay order
app.post('/api/payment/create-order', async (req, res) => {
  const { amount, gameId, currency = 'INR' } = req.body;
  if (!amount) return res.status(400).json({ error: 'Amount required' });

  if (!razorpay) {
    // Dev fallback – return a fake order
    return res.json({
      id: 'order_dev_' + Math.random().toString(36).slice(2, 9),
      amount: Math.round(amount * 100),
      currency,
      key: process.env.RAZORPAY_KEY_ID || 'rzp_test_DEV_KEY',
      dev: true,
    });
  }

  try {
    const order = await razorpay.orders.create({
      amount: Math.round(amount * 100), // paise
      currency,
      receipt: `gs_${gameId}_${Date.now()}`,
    });
    res.json({ ...order, key: process.env.RAZORPAY_KEY_ID });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Verify Razorpay payment signature
app.post('/api/payment/verify', async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, gameId, amount, userId } = req.body;

  let valid = false;
  if (razorpay && process.env.RAZORPAY_KEY_SECRET) {
    const body = razorpay_order_id + '|' + razorpay_payment_id;
    const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(body).digest('hex');
    valid = expected === razorpay_signature;
  } else {
    valid = true; // dev mode – always pass
  }

  if (!valid) return res.status(400).json({ error: 'Payment verification failed' });

  const orderId = 'GS-' + (razorpay_payment_id || Math.random().toString(36).slice(2, 9)).toUpperCase().slice(-8);
  const order = {
    orderId,
    razorpayOrderId: razorpay_order_id,
    razorpayPaymentId: razorpay_payment_id,
    gameId, amount,
    userId: userId || 'guest',
    status: 'paid',
    createdAt: new Date().toISOString(),
  };
  await fsSaveOrder(order);
  res.json({ success: true, orderId, gameId, amount });
});

// Legacy / UPI / Wallet fallback (mock)
app.post('/api/payment/process', async (req, res) => {
  const { gameId, method, amount, userId } = req.body;
  const orderId = 'GS-' + Math.random().toString(36).slice(2, 9).toUpperCase();
  const order = { orderId, gameId, amount, method, userId: userId || 'guest', status: 'paid', createdAt: new Date().toISOString() };
  await fsSaveOrder(order);
  setTimeout(() => res.json({ success: true, orderId, gameId, amount, method }), 1200);
});

// ── ADMIN ROUTES ──────────────────────────────────────────
app.get('/api/admin/stats', async (req, res) => {
  const totalGames = games.length;
  const freeGames  = games.filter(g => g.price === 0).length;
  const avgPrice   = (games.filter(g => g.price > 0).reduce((s, g) => s + g.price, 0) / (totalGames - freeGames) || 0).toFixed(0);
  const allUsers   = await fsGetUsers();
  const allOrders  = await fsGetOrders();
  const revenue    = allOrders.reduce((s, o) => s + (Number(o.amount) || 0), 0);
  res.json({
    totalGames, freeGames, paidGames: totalGames - freeGames,
    avgPrice: Number(avgPrice),
    totalUsers: allUsers.length,
    revenue: revenue || 142800,
    ordersToday: allOrders.filter(o => o.createdAt && o.createdAt.slice(0,10) === new Date().toISOString().slice(0,10)).length || 47,
  });
});

// Full user list for admin
app.get('/api/admin/users', async (req, res) => {
  try {
    const allUsers = await fsGetUsers();
    const allOrders = await fsGetOrders();
    // Attach order stats to each user
    const enriched = allUsers.map(u => {
      const userOrders = allOrders.filter(o => o.userId === (u.uid || u.id || u.email));
      return {
        ...u,
        password: undefined, // never send passwords
        orderCount: userOrders.length,
        totalSpent: userOrders.reduce((s, o) => s + (Number(o.amount) || 0), 0),
        lastOrder: userOrders.sort((a,b) => b.createdAt > a.createdAt ? 1 : -1)[0] || null,
      };
    });
    res.json(enriched);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Single user detail
app.get('/api/admin/users/:uid', async (req, res) => {
  try {
    const allUsers  = await fsGetUsers();
    const allOrders = await fsGetOrders();
    const user = allUsers.find(u => (u.uid || u.id || u.email) === req.params.uid);
    if (!user) return res.status(404).json({ error: 'User not found' });
    const userOrders = allOrders.filter(o => o.userId === (user.uid || user.id || user.email));
    res.json({ ...user, password: undefined, orders: userOrders });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GAME FILE UPLOADS ────────────────────────────────────
const UPLOADS_DIR = require('path').join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const gameId = req.params.id || 'unknown';
    const ext    = require('path').extname(file.originalname) || '.bin';
    cb(null, `${gameId}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 * 1024 }, // 5 GB max
});

// Upload a file for a game
app.post('/api/games/:id/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const fileUrl = `/api/games/${req.params.id}/download`;
  // Store file info on the game
  const idx = games.findIndex(g => g.id === req.params.id);
  if (idx !== -1) {
    games[idx].downloadFile = req.file.filename;
    games[idx].downloadUrl  = fileUrl;
    games[idx].fileSize     = req.file.size;
    games[idx].fileName     = req.file.originalname;
  }
  res.json({ success: true, fileUrl, fileName: req.file.originalname, fileSize: req.file.size });
});

// Download a game file
app.get('/api/games/:id/download', (req, res) => {
  const game = games.find(g => g.id === req.params.id);
  if (!game || !game.downloadFile) return res.status(404).json({ error: 'No file uploaded for this game' });
  const filePath = require('path').join(UPLOADS_DIR, game.downloadFile);
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'File not found on disk' });
  res.download(filePath, game.fileName || game.downloadFile);
});

// Remove a game's uploaded file
app.delete('/api/games/:id/upload', (req, res) => {
  const idx = games.findIndex(g => g.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Game not found' });
  const game = games[idx];
  if (game.downloadFile) {
    const filePath = require('path').join(UPLOADS_DIR, game.downloadFile);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    games[idx] = { ...games[idx], downloadFile: null, downloadUrl: null, fileSize: null, fileName: null };
  }
  res.json({ success: true });
});

// List all uploaded files (admin)
app.get('/api/admin/files', (req, res) => {
  const filesOnDisk = fs.existsSync(UPLOADS_DIR) ? fs.readdirSync(UPLOADS_DIR) : [];
  const gamesWithFiles = games.filter(g => g.downloadFile).map(g => ({
    id: g.id, title: g.title, fileName: g.fileName, fileSize: g.fileSize,
    downloadUrl: g.downloadUrl, price: g.price,
  }));
  res.json({ gamesWithFiles, totalFiles: filesOnDisk.length });
});

// ── SITE SETTINGS ────────────────────────────────────────
let siteSettings = {
  // Header
  storeName:    'GameStore',
  storeTagline: 'Your ultimate gaming destination',
  storeIcon:    'bi-controller',
  navLinks: [
    { label: 'Battle Royale', category: 'battle-royale' },
    { label: 'FPS / Shooter', category: 'fps-shooter'   },
    { label: 'RPG',           category: 'rpg'            },
    { label: 'Action',        category: 'action'         },
    { label: 'Racing',        category: 'racing'         },
    { label: 'Free Games',    category: 'free'           },
  ],
  // Footer
  footerText:       '© 2025 GameStore. All rights reserved.',
  footerSubtext:    'All prices in INR · Instant digital delivery',
  footerLinks: [
    { label: 'Privacy Policy', url: '#' },
    { label: 'Terms of Service', url: '#' },
    { label: 'Support', url: '#' },
    { label: 'Refund Policy', url: '#' },
  ],
  socialLinks: [
    { icon: 'bi-twitter-x',  url: '#', label: 'Twitter'   },
    { icon: 'bi-instagram',  url: '#', label: 'Instagram' },
    { icon: 'bi-discord',    url: '#', label: 'Discord'   },
    { icon: 'bi-youtube',    url: '#', label: 'YouTube'   },
  ],
  // Business / contact info
  businessName:    'GameStore Pvt. Ltd.',
  businessEmail:   'support@gamestore.in',
  businessPhone:   '+91 98765 43210',
  businessAddress: 'Mumbai, Maharashtra, India',
  businessGST:     'GST27AAAAA0000A1Z5',
  supportHours:    '24/7 · 365 days',
  // Theme
  accentColor:     '#d57454',
  // Announcement banner
  bannerEnabled:   false,
  bannerText:      '🎮 MEGA SALE — Up to 50% off on all games this weekend!',
  bannerColor:     '#d57454',
};

app.get('/api/settings',        (req, res) => res.json(siteSettings));
app.put('/api/settings',        (req, res) => { siteSettings = { ...siteSettings, ...req.body }; res.json(siteSettings); });
app.put('/api/settings/reset',  (req, res) => { /* keep defaults already set */ res.json(siteSettings); });

// ── SERVE REACT BUILD ─────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));
  app.get('*', (req, res) => res.sendFile(path.join(__dirname, '../client/build/index.html')));
}

const PORT = process.env.PORT || 5000;
initFirestore().then(() => {
  app.listen(PORT, () => console.log(`GameStore server on http://localhost:${PORT}`));
});
