import requests
import os
import re
import uuid
import PyPDF2
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, send_from_directory, g
from flask_cors import CORS
from authlib.integrations.flask_client import OAuth
from werkzeug.utils import secure_filename

import sqlite3
import bcrypt
import jwt
import datetime
from functools import wraps

ALLOWED_EXTENSIONS = {'pdf'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

app = Flask(__name__)
CORS(app)
app.secret_key = "flask_session_secret"

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max

SECRET_KEY = "your_secret_key"

# --- Google OAuth ---
oauth = OAuth(app)
google = oauth.register(
    name='google',
    client_id='YOUR_CLIENT_ID',
    client_secret='YOUR_CLIENT_SECRET',
    access_token_url='https://oauth2.googleapis.com/token',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    client_kwargs={'scope': 'openid email profile'},
    jwks_uri='https://www.googleapis.com/oauth2/v3/certs',
)

@app.route('/login/google')
def login_google():
    redirect_uri = url_for('google_callback', _external=True)
    return google.authorize_redirect(redirect_uri)

@app.route('/login/google/callback')
def google_callback():
    token = google.authorize_access_token()
    user_info = google.get('userinfo').json()
    email = user_info['email']

    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE email=?", (email,))
    existing = c.fetchone()
    if not existing:
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, 'google'))
        conn.commit()
    conn.close()

    jwt_token = jwt.encode({
        "email": email,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=2)
    }, SECRET_KEY, algorithm="HS256")

    # Redirect to profile with token as query param (frontend reads and stores it)
    return redirect(f'/profile?token={jwt_token}')

def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            password TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT,
            filename TEXT,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')

        if not token:
            return jsonify({"message": "Token missing"}), 401

        try:
            if token.startswith("Bearer "):
                token = token.split(" ", 1)[1]

            payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            g.current_user_email = payload.get("email")
            if not g.current_user_email:
                return jsonify({"message": "Invalid token"}), 401
        except Exception:
            return jsonify({"message": "Invalid token"}), 401

        return f(*args, **kwargs)

    return decorated

@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    conn = sqlite3.connect('users.db')
    c = conn.cursor()

    try:
        c.execute("INSERT INTO users (email, password) VALUES (?, ?)", (email, hashed))
        conn.commit()
        return jsonify({"success": True, "message": "Signup successful"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})
    finally:
        conn.close()

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    conn = sqlite3.connect('users.db')
    c = conn.cursor()

    c.execute("SELECT password FROM users WHERE email=?", (email,))
    user = c.fetchone()
    conn.close()

    try:
        if user and bcrypt.checkpw(password.encode('utf-8'), user[0]):
            token = jwt.encode({
                "email": email,
                "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=2)
            }, SECRET_KEY, algorithm="HS256")
            return jsonify({"success": True, "token": token})
        
        return jsonify({"success": False, "message": "Invalid credentials"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

@app.route('/api/profile')
@token_required
def api_profile():
    return jsonify({
        "message": "Welcome to your profile",
        "email": g.current_user_email
    })

@app.route('/api/upload_report', methods=['POST'])
@token_required
def upload_report():
    if 'file' not in request.files:
        return jsonify({"success": False, "message": "No file uploaded"})

    file = request.files['file']
    email = g.current_user_email

    if file.filename == '':
        return jsonify({"success": False, "message": "No selected file"})

    if not allowed_file(file.filename):
        return jsonify({"success": False, "message": "Only PDF files are allowed"})

    try:
        filename = str(uuid.uuid4()) + "_" + secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("INSERT INTO reports (email, filename) VALUES (?, ?)", (email, filename))
        conn.commit()
        conn.close()

        return jsonify({"success": True, "message": "File uploaded successfully", "file": filename})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

@app.route('/api/get_reports')
@token_required
def get_reports():
    email = g.current_user_email
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT filename, uploaded_at FROM reports WHERE email=? ORDER BY uploaded_at DESC", (email,))
    data = c.fetchall()
    conn.close()
    return jsonify({"reports": [{"filename": r[0], "uploaded_at": r[1]} for r in data]})

@app.route('/api/download_report/<filename>')
@token_required
def download_report(filename):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute(
        "SELECT 1 FROM reports WHERE email=? AND filename=?",
        (g.current_user_email, filename)
    )
    report = c.fetchone()
    conn.close()

    if not report:
        return jsonify({"success": False, "message": "Report not found"}), 404

    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

# --- PDF Analysis & Disease Detection ---
def extract_text_from_pdf(filepath):
    text = ""
    try:
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                text += page.extract_text() or ""
    except Exception as e:
        text = ""
    return text

def extract_medical_values(text):
    data = {}
    patterns = {
        "hemoglobin": r"hemoglobin[:\s]+([\d.]+)",
        "glucose":    r"glucose[:\s]+([\d.]+)",
        "cholesterol": r"cholesterol[:\s]+([\d.]+)",
        "bp":         r"(\d{2,3}/\d{2,3})",
        "wbc":        r"wbc[:\s]+([\d.]+)",
        "rbc":        r"rbc[:\s]+([\d.]+)",
        "platelets":  r"platelets[:\s]+([\d]+)"
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, text.lower())
        if match:
            data[key] = match.group(1)
    return data

def detect_diseases(values):
    results = []
    normal = {}
    try:
        if "glucose" in values:
            g = float(values["glucose"])
            if g > 126:
                results.append({"flag": "⚠️ Possible Diabetes", "detail": f"Glucose: {g} mg/dL (normal <126)", "level": "danger"})
            elif g > 100:
                results.append({"flag": "⚡ Pre-Diabetes Risk", "detail": f"Glucose: {g} mg/dL (normal <100)", "level": "warning"})
            else:
                normal["glucose"] = f"{g} mg/dL ✅"

        if "hemoglobin" in values:
            h = float(values["hemoglobin"])
            if h < 12:
                results.append({"flag": "⚠️ Possible Anemia", "detail": f"Hemoglobin: {h} g/dL (normal >12)", "level": "danger"})
            elif h < 13.5:
                results.append({"flag": "⚡ Low Hemoglobin", "detail": f"Hemoglobin: {h} g/dL (normal >13.5)", "level": "warning"})
            else:
                normal["hemoglobin"] = f"{h} g/dL ✅"

        if "cholesterol" in values:
            c = float(values["cholesterol"])
            if c > 240:
                results.append({"flag": "⚠️ High Cholesterol (Heart Risk)", "detail": f"Cholesterol: {c} mg/dL (normal <200)", "level": "danger"})
            elif c > 200:
                results.append({"flag": "⚡ Borderline Cholesterol", "detail": f"Cholesterol: {c} mg/dL (normal <200)", "level": "warning"})
            else:
                normal["cholesterol"] = f"{c} mg/dL ✅"

        if "bp" in values:
            sys_bp, dia_bp = map(int, values["bp"].split("/"))
            if sys_bp > 140 or dia_bp > 90:
                results.append({"flag": "⚠️ High Blood Pressure", "detail": f"BP: {values['bp']} mmHg (normal <120/80)", "level": "danger"})
            elif sys_bp > 130 or dia_bp > 80:
                results.append({"flag": "⚡ Elevated Blood Pressure", "detail": f"BP: {values['bp']} mmHg", "level": "warning"})
            else:
                normal["blood_pressure"] = f"{values['bp']} mmHg ✅"

        if "platelets" in values:
            p = int(values["platelets"])
            if p < 150000:
                results.append({"flag": "⚠️ Low Platelets (Thrombocytopenia)", "detail": f"Platelets: {p}/μL (normal 150000-400000)", "level": "danger"})
            else:
                normal["platelets"] = f"{p}/μL ✅"
    except:
        pass
    return results, normal

@app.route('/api/analyze_report', methods=['POST'])
def analyze_report():
    if 'file' not in request.files:
        return jsonify({"success": False, "message": "No file uploaded"})

    file = request.files['file']
    if not allowed_file(file.filename):
        return jsonify({"success": False, "message": "Only PDF files allowed"})

    try:
        filename = str(uuid.uuid4()) + "_" + secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        text = extract_text_from_pdf(filepath)

        if not text.strip():
            return jsonify({
                "success": True,
                "diseases": [],
                "normal": {},
                "values": {},
                "note": "Could not extract text from this PDF. It may be a scanned image."
            })

        values = extract_medical_values(text)
        diseases, normal = detect_diseases(values)

        return jsonify({
            "success": True,
            "values": values,
            "diseases": diseases,
            "normal": normal,
            "note": "AI-based suggestion only. Not a medical diagnosis. Always consult a doctor."
        })
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

def fetch_drug_info(drug_name):
    # Improved FDA search query
    url = f"https://api.fda.gov/drug/label.json?search={drug_name}&limit=1"
    
    try:
        response = requests.get(url, timeout=5)
        data = response.json()

        if "results" in data:
            result = data["results"][0]

            warnings = result.get("warnings", ["No warnings found"])[0]
            purpose = result.get("purpose", ["No purpose info"])[0]

            return {
                "warnings": warnings,
                "purpose": purpose
            }

    except:
        return None

@app.route('/api/check_allergy', methods=['POST'])
def api_check_allergy():
    try:
        data = request.json
        medicine = data.get('medicine', '').lower()

        info = fetch_drug_info(medicine)

        if info:
            return jsonify({
                "status": "warning",
                "message": f"⚠ {info['warnings']}"
            })
        else:
            return jsonify({
                "status": "safe",
                "message": "No data found. Seems safe."
            })
    except Exception as e:
        return jsonify({"status": "error", "message": "Failed to check allergy."})

@app.route('/api/chat', methods=['POST'])
def chat():
    data = request.json
    msg = data.get('message', '').lower()
    
    if 'allergy' in msg or 'check' in msg:
        reply = "You can use our 'Allergy Checker' tool to check for risks in your medicine."
    elif 'profile' in msg or 'report' in msg:
        reply = "You can upload and analyze your medical reports in the 'Profile' section."
    else:
        reply = "Hello! I am your Medicine Checker assistant. How can I help you today?"
        
    return jsonify({"reply": reply})

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/signup')
def signup_page():
    return render_template('signup.html')

@app.route('/profile')
def profile_page():
    return render_template('profile.html')

@app.route('/allergy-checker')
def allergy_page():
    return render_template('allergy-checker.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
