const express = require('express');
const app = express();
const PORT = 3000;

// Middleware to read form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Registration Route
app.post('/register', (req, res) => {
    const { name, email, password } = req.body;

    console.log("Name:", name);
    console.log("Email:", email);
    console.log("Password:", password);

    res.send("Registration Successful!");
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});